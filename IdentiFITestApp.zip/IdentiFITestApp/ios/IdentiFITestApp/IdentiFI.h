//
//  IdentiFI.h
//  IdentiFI
//
//  Copyright © 2015-2025 S.I.C. Biometrics Inc. All rights reserved.
//
//  Update History
//  --------------
//  2025-03-12  Version 1.6.0.0
//              Fix the connect method which fails to connect on iOS 18.x
//
//              Changed the startFirmwareUpdate(NSData *) newFirmware to add a legacy option for IdentiFI running with firmware version < v2.3.0.
//              New method  - (void)startFirmwareUpdate:(NSData *) newFirmware toLegacyFirmware: (BOOL) legacyFirmwareUpdateMethod (need to be =true if target is running < v2.3.0)
//
//              Rebuilted for Xcode Simulator running on Mx CPU.
//
//              Partial migration to background thread (and associated callbacks) for:
//              - connect
//              - startCaptureOneFinger:
//              - startCaptureTwoFinger:
//              - startCaptureFourFinger:
//              - startCaptureRollFinger:
//              - getSegmentedFpImageSavedAt:

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface IdentiFI : NSObject
{
    id delegate;
}

//Library setup
- (void) setDelegate:(id)newDelegate;
- (id)init;

//Communication link
- (void) connect;
- (void) disconnect;

//Fingerprint capture
- (void) cancelFpCapture;
- (void) startCaptureOneFinger:(int) savedAtIndex;
- (void) startCaptureTwoFinger:(int) savedAtIndex;
- (void) startCaptureFourFinger:(int) savedAtIndex;
- (void) startCaptureRollFinger:(int) savedAtIndex;

//Iris capture
- (void) cancelIrisCapture;
- (void) startCaptureIris;

//IdentiFI's settings
- (void) setLEDBrightness:(int) LEDBrightness;
- (void) getLEDBrightness;
- (void) setMinimumNFIQScore:(int) minimumNFIQScore;
- (void) getPowerOffMode;
- (void) setPowerOffMode:(int) secondsToPowerOff;

//Saved fingerprint images. (Saved into volatile memory! Fingerprint images lost on poweroff.)
- (void) clearSavedFpImages:(int) savedAtIndex;
- (void) getNfiqScoreFromImageSavedAt:(int) savedAtIndex;
- (void) getSegmentedFpImageSavedAt:(int) savedAtIndex;
- (void) getWSQEncodedFpImageFromImageSavedAt:(int) savedAtIndex croppedImage:(BOOL) croppedImage;
- (void) isFingerDuplicated:(int) savedAtIndex securityLevel:(int) securityLevel;

//Fingerprint Sensor Power Management
- (void) getFpPowerStatus;
- (void) setFpPowerOn;
- (void) setFpPowerOff;

//Iris Sensor Power Management
- (void) getIrisPowerStatus;
- (void) setIrisPowerOn;
- (void) setIrisPowerOff;

//Device information
- (void) getBatteryPercentage;
- (void) getDeviceSerialNumber;
- (void) getFirmwareVersion;
- (NSString *)getLibraryVersion;
- (void) getModelNumber;
- (void) getReaderDescription;

//Keypad's LEDs control
- (void) setLEDControlForPowerLED:(int) power FpLED:(int) fp ComLED:(int) com IrisLED:(int) iris mSecOn:(int) mOn mSecOff:(int) mOff;

//Firmware update (legacyFirmwareUpdateMethod need to be =true if target is running < v2.3.0)
- (void)startFirmwareUpdate:(NSData *) newFirmware toLegacyFirmware: (BOOL) legacyFirmwareUpdateMethod;
@end

@protocol IdentiFI_Delegate <NSObject>

//Communication Link
- (void) onConnection;
- (void) onConnectionError:(NSString *) errorDescription;
- (void) onConnectionTimeOut;
- (void) onDisconnection;

//Finger capture
- (void) onCancelFpCapture;
- (void) onFpCaptureStatus:(int) fpCaptureStatus;
- (void) onStreaming:             (UIImage *) fpImage;
- (void) onStreamingRolledFp:     (UIImage *) fpImage          rollingState:   (int) currentState   verticalLineX:(int) currentXPosition;
- (void) onLastFrame:             (UIImage *) fpImage          fpImageSavedAt: (int) savedAtIndex;
- (void) onLastFrame_RAW:         (NSData *)  rawFpImageData   fpImageSavedAt: (int) savedAtIndex;
- (void) onLastFrameRolledFp:     (UIImage *) fpImage          fpImageSavedAt: (int) savedAtIndex;
- (void) onLastFrameRolledFp_RAW: (NSData *)  rawFpImageData   fpImageSavedAt: (int) savedAtIndex;

//Iris capture
- (void) onCancelIrisCapture;
- (void) onIrisCaptureStatus:(int) irisCaptureStatus;
- (void) onStreamingLeftIris:(UIImage *) leftIrisImage RightIris:(UIImage *) rightIrisImage;
- (void) onLastFrameLeftIris:(UIImage *) leftIrisImage RightIris:(UIImage *) rightIrisImage  LeftIrisTotalScore:(int) leftTotalScore LeftIrisUsableArea:(int) leftUsabeArea RightIrisTotalScore:(int) rightTotalScore RightIrisUsableArea:(int) rightUsabeArea;

//IdentiFI's settings
- (void) onGetLEDBrightness:(int) ledBrightness;
- (void) onSetLEDBrightness:(int) ledBrightness;
- (void) onSetMinimumNFIQScore:(int) minimumNFIQScore;


//Saved fingerprint images.
- (void) onGetNfiqScore:(int) nfiqScore fromImageSavedAt: (int) savedAtIndex;
- (void) onGetSegmentedFpImage_RAW:(NSData *) rawFpImageData fromImageSavedAt:(int)savedAtIndex;
- (void) onGetWSQEncodedFpImage:(NSData *) wsqEncodedFpImageData fromImageSavedAt:(int) savedAtIndex;
- (void) onIsFingerDuplicated:(int) isFingerDuplicated;
- (void) onSavedFpImagesCleared:(int) savedAtIndex;

//Power management
- (void) onGetPowerOffMode:(int) secondsToPowerOff;
- (void) onSetPowerOffMode:(int) secondsToPowerOff;

- (void) onGetFpPowerStatus:(Boolean) irisPowerStatus;
- (void) onSetFpPowerOn:(Boolean) irisPowerStatus;
- (void) onSetFpPowerOff;

- (void) onGetIrisPowerStatus:(Boolean) irisPowerStatus;
- (void) onSetIrisPowerOn:(Boolean) irisPowerStatus;
- (void) onSetIrisPowerOff;

//Device information
- (void) onGetBatteryPercentage:(int) percentLevel;
- (void) onGetDeviceSerialNumber:(NSString*) serialNumber;
- (void) onGetFirmwareVersion:(NSString *) version;
- (void) onGetModelNumber:(NSString *) model;
- (void) onGetReaderDescription:(NSString *) deviceDescription;

//Keypad's LEDs control
- (void) onSetLEDControlForPowerLED:(int) power FpLED:(int) fp ComLED:(int) com IrisLED:(int) iris mSecOn:(int) mOn mSecOff:(int) mOff;

//Firmware update
- (void) onFirmwareTransferCompleted:(long) transferResult;
@end