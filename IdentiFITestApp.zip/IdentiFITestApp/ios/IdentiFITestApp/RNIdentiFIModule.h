//
//  RNIdentiFIModule.h
//  IdentiFITestApp
//
//  React Native bridge for IdentiFI SDK
//

#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

@interface RNIdentiFIModule : RCTEventEmitter <RCTBridgeModule>

@end