//
//  RNIdentiFIModule.m
//  IdentiFITestApp
//
//  React Native bridge for IdentiFI SDK
//

#import "RNIdentiFIModule.h"
#import <React/RCTLog.h>

@interface RNIdentiFIModule()
@property (nonatomic, strong) id identiFIDevice;
@property (nonatomic, assign) BOOL hasListeners;
@end

@implementation RNIdentiFIModule

RCT_EXPORT_MODULE();

+ (BOOL)requiresMainQueueSetup
{
    return YES;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        // Initialize IdentiFI device when available
        // self.identiFIDevice = [[IdentiFI alloc] init];
        // [self.identiFIDevice setDelegate:self];
    }
    return self;
}

- (NSArray<NSString *> *)supportedEvents
{
    return @[
        @"onConnection",
        @"onConnectionError", 
        @"onConnectionTimeOut",
        @"onDisconnection",
        @"onCancelFpCapture",
        @"onFpCaptureStatus",
        @"onStreaming",
        @"onStreamingRolledFp",
        @"onLastFrame",
        @"onLastFrame_RAW",
        @"onLastFrameRolledFp",
        @"onLastFrameRolledFp_RAW",
        @"onCancelIrisCapture",
        @"onIrisCaptureStatus",
        @"onStreamingLeftIris",
        @"onLastFrameLeftIris",
        @"onGetLEDBrightness",
        @"onSetLEDBrightness",
        @"onSetMinimumNFIQScore",
        @"onGetNfiqScore",
        @"onGetSegmentedFpImage_RAW",
        @"onGetWSQEncodedFpImage",
        @"onIsFingerDuplicated",
        @"onSavedFpImagesCleared",
        @"onGetPowerOffMode",
        @"onSetPowerOffMode",
        @"onGetFpPowerStatus",
        @"onSetFpPowerOn",
        @"onSetFpPowerOff",
        @"onGetIrisPowerStatus",
        @"onSetIrisPowerOn",
        @"onSetIrisPowerOff",
        @"onGetBatteryPercentage",
        @"onGetDeviceSerialNumber",
        @"onGetFirmwareVersion",
        @"onGetModelNumber",
        @"onGetReaderDescription",
        @"onSetLEDControlForPowerLED",
        @"onFirmwareTransferCompleted"
    ];
}

// MARK: - Listener Management

- (void)startObserving
{
    self.hasListeners = YES;
}

- (void)stopObserving
{
    self.hasListeners = NO;
}

// MARK: - Connection Methods

RCT_EXPORT_METHOD(connect:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI connect called");
    // TODO: Implement actual connection logic
    // [self.identiFIDevice connect];
    resolve(@"Connection initiated");
}

RCT_EXPORT_METHOD(disconnect:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI disconnect called");
    // TODO: Implement actual disconnection logic
    // [self.identiFIDevice disconnect];
    resolve(@"Disconnection initiated");
}

// MARK: - Fingerprint Capture Methods

RCT_EXPORT_METHOD(startCaptureOneFinger:(NSInteger)savedAtIndex
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI startCaptureOneFinger called with index: %ld", (long)savedAtIndex);
    // TODO: Implement actual fingerprint capture
    // [self.identiFIDevice startCaptureOneFinger:(int)savedAtIndex];
    resolve(@"Single finger capture started");
}

RCT_EXPORT_METHOD(startCaptureTwoFinger:(NSInteger)savedAtIndex
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI startCaptureTwoFinger called with index: %ld", (long)savedAtIndex);
    // TODO: Implement actual two finger capture
    // [self.identiFIDevice startCaptureTwoFinger:(int)savedAtIndex];
    resolve(@"Two finger capture started");
}

RCT_EXPORT_METHOD(startCaptureFourFinger:(NSInteger)savedAtIndex
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI startCaptureFourFinger called with index: %ld", (long)savedAtIndex);
    // TODO: Implement actual four finger capture
    // [self.identiFIDevice startCaptureFourFinger:(int)savedAtIndex];
    resolve(@"Four finger capture started");
}

RCT_EXPORT_METHOD(startCaptureRollFinger:(NSInteger)savedAtIndex
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI startCaptureRollFinger called with index: %ld", (long)savedAtIndex);
    // TODO: Implement actual roll finger capture
    // [self.identiFIDevice startCaptureRollFinger:(int)savedAtIndex];
    resolve(@"Roll finger capture started");
}

RCT_EXPORT_METHOD(cancelFpCapture:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI cancelFpCapture called");
    // TODO: Implement actual cancel capture
    // [self.identiFIDevice cancelFpCapture];
    resolve(@"Fingerprint capture cancelled");
}

// MARK: - Iris Capture Methods

RCT_EXPORT_METHOD(startCaptureIris:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI startCaptureIris called");
    // TODO: Implement actual iris capture
    // [self.identiFIDevice startCaptureIris];
    resolve(@"Iris capture started");
}

RCT_EXPORT_METHOD(cancelIrisCapture:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI cancelIrisCapture called");
    // TODO: Implement actual cancel iris capture
    // [self.identiFIDevice cancelIrisCapture];
    resolve(@"Iris capture cancelled");
}

// MARK: - Device Information Methods

RCT_EXPORT_METHOD(getBatteryPercentage:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI getBatteryPercentage called");
    // TODO: Implement actual battery reading
    // [self.identiFIDevice getBatteryPercentage];
    resolve(@"Battery request sent");
}

RCT_EXPORT_METHOD(getDeviceSerialNumber:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI getDeviceSerialNumber called");
    // TODO: Implement actual serial number reading
    // [self.identiFIDevice getDeviceSerialNumber];
    resolve(@"Serial number request sent");
}

RCT_EXPORT_METHOD(getFirmwareVersion:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI getFirmwareVersion called");
    // TODO: Implement actual firmware version reading
    // [self.identiFIDevice getFirmwareVersion];
    resolve(@"Firmware version request sent");
}

RCT_EXPORT_METHOD(getLibraryVersion:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI getLibraryVersion called");
    // TODO: Implement actual library version reading
    // NSString *version = [self.identiFIDevice getLibraryVersion];
    resolve(@"1.6.0.0");
}

RCT_EXPORT_METHOD(getModelNumber:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI getModelNumber called");
    // TODO: Implement actual model number reading
    // [self.identiFIDevice getModelNumber];
    resolve(@"Model number request sent");
}

RCT_EXPORT_METHOD(getReaderDescription:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI getReaderDescription called");
    // TODO: Implement actual reader description
    // [self.identiFIDevice getReaderDescription];
    resolve(@"Reader description request sent");
}

// MARK: - Settings Methods

RCT_EXPORT_METHOD(setLEDBrightness:(NSInteger)brightness
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI setLEDBrightness called with brightness: %ld", (long)brightness);
    // TODO: Implement actual LED brightness setting
    // [self.identiFIDevice setLEDBrightness:(int)brightness];
    resolve(@"LED brightness set");
}

RCT_EXPORT_METHOD(getLEDBrightness:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI getLEDBrightness called");
    // TODO: Implement actual LED brightness reading
    // [self.identiFIDevice getLEDBrightness];
    resolve(@"LED brightness request sent");
}

RCT_EXPORT_METHOD(setMinimumNFIQScore:(NSInteger)score
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI setMinimumNFIQScore called with score: %ld", (long)score);
    // TODO: Implement actual NFIQ score setting
    // [self.identiFIDevice setMinimumNFIQScore:(int)score];
    resolve(@"Minimum NFIQ score set");
}

// MARK: - Power Management Methods

RCT_EXPORT_METHOD(setFpPowerOn:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI setFpPowerOn called");
    // TODO: Implement actual FP power on
    // [self.identiFIDevice setFpPowerOn];
    resolve(@"Fingerprint sensor power on");
}

RCT_EXPORT_METHOD(setFpPowerOff:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI setFpPowerOff called");
    // TODO: Implement actual FP power off
    // [self.identiFIDevice setFpPowerOff];
    resolve(@"Fingerprint sensor power off");
}

RCT_EXPORT_METHOD(getFpPowerStatus:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI getFpPowerStatus called");
    // TODO: Implement actual FP power status
    // [self.identiFIDevice getFpPowerStatus];
    resolve(@"FP power status request sent");
}

RCT_EXPORT_METHOD(setIrisPowerOn:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI setIrisPowerOn called");
    // TODO: Implement actual iris power on
    // [self.identiFIDevice setIrisPowerOn];
    resolve(@"Iris sensor power on");
}

RCT_EXPORT_METHOD(setIrisPowerOff:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI setIrisPowerOff called");
    // TODO: Implement actual iris power off
    // [self.identiFIDevice setIrisPowerOff];
    resolve(@"Iris sensor power off");
}

RCT_EXPORT_METHOD(getIrisPowerStatus:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI getIrisPowerStatus called");
    // TODO: Implement actual iris power status
    // [self.identiFIDevice getIrisPowerStatus];
    resolve(@"Iris power status request sent");
}

// MARK: - Saved Images Methods

RCT_EXPORT_METHOD(clearSavedFpImages:(NSInteger)savedAtIndex
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI clearSavedFpImages called with index: %ld", (long)savedAtIndex);
    // TODO: Implement actual clear saved images
    // [self.identiFIDevice clearSavedFpImages:(int)savedAtIndex];
    resolve(@"Saved FP images cleared");
}

RCT_EXPORT_METHOD(getNfiqScoreFromImageSavedAt:(NSInteger)savedAtIndex
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI getNfiqScoreFromImageSavedAt called with index: %ld", (long)savedAtIndex);
    // TODO: Implement actual NFIQ score retrieval
    // [self.identiFIDevice getNfiqScoreFromImageSavedAt:(int)savedAtIndex];
    resolve(@"NFIQ score request sent");
}

RCT_EXPORT_METHOD(getSegmentedFpImageSavedAt:(NSInteger)savedAtIndex
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI getSegmentedFpImageSavedAt called with index: %ld", (long)savedAtIndex);
    // TODO: Implement actual segmented image retrieval
    // [self.identiFIDevice getSegmentedFpImageSavedAt:(int)savedAtIndex];
    resolve(@"Segmented FP image request sent");
}

RCT_EXPORT_METHOD(getWSQEncodedFpImageFromImageSavedAt:(NSInteger)savedAtIndex
                  croppedImage:(BOOL)croppedImage
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI getWSQEncodedFpImageFromImageSavedAt called with index: %ld, cropped: %@", (long)savedAtIndex, croppedImage ? @"YES" : @"NO");
    // TODO: Implement actual WSQ image retrieval
    // [self.identiFIDevice getWSQEncodedFpImageFromImageSavedAt:(int)savedAtIndex croppedImage:croppedImage];
    resolve(@"WSQ encoded FP image request sent");
}

RCT_EXPORT_METHOD(isFingerDuplicated:(NSInteger)savedAtIndex
                  securityLevel:(NSInteger)securityLevel
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    RCTLogInfo(@"IdentiFI isFingerDuplicated called with index: %ld, security level: %ld", (long)savedAtIndex, (long)securityLevel);
    // TODO: Implement actual finger duplication check
    // [self.identiFIDevice isFingerDuplicated:(int)savedAtIndex securityLevel:(int)securityLevel];
    resolve(@"Finger duplication check sent");
}

// Helper method to send events to React Native
- (void)sendEventWithName:(NSString *)eventName body:(id)body
{
    if (self.hasListeners) {
        [super sendEventWithName:eventName body:body];
    }
}

@end

// MARK: - IdentiFI Delegate Methods (Commented for now, will be implemented when framework is linked)

/*
@interface RNIdentiFIModule () <IdentiFI_Delegate>
@end

@implementation RNIdentiFIModule (IdentiFIDelegate)

// Communication Link
- (void)onConnection
{
    [self sendEventWithName:@"onConnection" body:@{}];
}

- (void)onConnectionError:(NSString *)errorDescription
{
    [self sendEventWithName:@"onConnectionError" body:@{@"error": errorDescription ?: @"Unknown error"}];
}

- (void)onConnectionTimeOut
{
    [self sendEventWithName:@"onConnectionTimeOut" body:@{}];
}

- (void)onDisconnection
{
    [self sendEventWithName:@"onDisconnection" body:@{}];
}

// Finger capture
- (void)onCancelFpCapture
{
    [self sendEventWithName:@"onCancelFpCapture" body:@{}];
}

- (void)onFpCaptureStatus:(int)fpCaptureStatus
{
    [self sendEventWithName:@"onFpCaptureStatus" body:@{@"status": @(fpCaptureStatus)}];
}

- (void)onStreaming:(UIImage *)fpImage
{
    // Convert UIImage to base64 string for React Native
    NSData *imageData = UIImagePNGRepresentation(fpImage);
    NSString *base64String = [imageData base64EncodedStringWithOptions:0];
    [self sendEventWithName:@"onStreaming" body:@{@"image": base64String}];
}

- (void)onStreamingRolledFp:(UIImage *)fpImage rollingState:(int)currentState verticalLineX:(int)currentXPosition
{
    NSData *imageData = UIImagePNGRepresentation(fpImage);
    NSString *base64String = [imageData base64EncodedStringWithOptions:0];
    [self sendEventWithName:@"onStreamingRolledFp" body:@{
        @"image": base64String,
        @"rollingState": @(currentState),
        @"verticalLineX": @(currentXPosition)
    }];
}

- (void)onLastFrame:(UIImage *)fpImage fpImageSavedAt:(int)savedAtIndex
{
    NSData *imageData = UIImagePNGRepresentation(fpImage);
    NSString *base64String = [imageData base64EncodedStringWithOptions:0];
    [self sendEventWithName:@"onLastFrame" body:@{
        @"image": base64String,
        @"savedAtIndex": @(savedAtIndex)
    }];
}

- (void)onLastFrame_RAW:(NSData *)rawFpImageData fpImageSavedAt:(int)savedAtIndex
{
    NSString *base64String = [rawFpImageData base64EncodedStringWithOptions:0];
    [self sendEventWithName:@"onLastFrame_RAW" body:@{
        @"rawData": base64String,
        @"savedAtIndex": @(savedAtIndex)
    }];
}

- (void)onLastFrameRolledFp:(UIImage *)fpImage fpImageSavedAt:(int)savedAtIndex
{
    NSData *imageData = UIImagePNGRepresentation(fpImage);
    NSString *base64String = [imageData base64EncodedStringWithOptions:0];
    [self sendEventWithName:@"onLastFrameRolledFp" body:@{
        @"image": base64String,
        @"savedAtIndex": @(savedAtIndex)
    }];
}

- (void)onLastFrameRolledFp_RAW:(NSData *)rawFpImageData fpImageSavedAt:(int)savedAtIndex
{
    NSString *base64String = [rawFpImageData base64EncodedStringWithOptions:0];
    [self sendEventWithName:@"onLastFrameRolledFp_RAW" body:@{
        @"rawData": base64String,
        @"savedAtIndex": @(savedAtIndex)
    }];
}

// Device information callbacks
- (void)onGetBatteryPercentage:(int)percentLevel
{
    [self sendEventWithName:@"onGetBatteryPercentage" body:@{@"percentage": @(percentLevel)}];
}

- (void)onGetDeviceSerialNumber:(NSString *)serialNumber
{
    [self sendEventWithName:@"onGetDeviceSerialNumber" body:@{@"serialNumber": serialNumber ?: @""}];
}

- (void)onGetFirmwareVersion:(NSString *)version
{
    [self sendEventWithName:@"onGetFirmwareVersion" body:@{@"version": version ?: @""}];
}

- (void)onGetModelNumber:(NSString *)model
{
    [self sendEventWithName:@"onGetModelNumber" body:@{@"model": model ?: @""}];
}

- (void)onGetReaderDescription:(NSString *)deviceDescription
{
    [self sendEventWithName:@"onGetReaderDescription" body:@{@"description": deviceDescription ?: @""}];
}

// Add other delegate methods as needed...

@end
*/