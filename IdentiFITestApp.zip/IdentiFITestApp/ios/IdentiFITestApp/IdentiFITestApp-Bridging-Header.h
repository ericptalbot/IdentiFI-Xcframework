//
//  IdentiFITestApp-Bridging-Header.h
//  IdentiFITestApp
//
//  Bridging header for IdentiFI framework
//

// Uncomment when IdentiFI framework is properly linked
// #import <IdentiFi/IdentiFi.h>
// Or if using header file directly:
// #import "IdentiFI.h"

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>