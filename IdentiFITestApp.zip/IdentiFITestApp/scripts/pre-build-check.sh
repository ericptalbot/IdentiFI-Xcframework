#!/bin/bash

echo "🔍 IdentiFI Test App - Pre-Build Check"
echo "======================================"

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: Run this script from the project root directory"
    exit 1
fi

echo "✅ In correct project directory"

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "❌ Error: node_modules not found. Run 'npm install'"
    exit 1
fi

echo "✅ Node modules installed"

# Check if iOS directory exists
if [ ! -d "ios" ]; then
    echo "❌ Error: iOS directory not found"
    exit 1
fi

echo "✅ iOS directory exists"

# Check if xcworkspace exists
if [ ! -f "ios/IdentiFITestApp.xcworkspace/contents.xcworkspacedata" ]; then
    echo "❌ Error: Xcode workspace not found. Run 'cd ios && pod install'"
    exit 1
fi

echo "✅ Xcode workspace configured"

# Check if Frameworks directory exists
if [ ! -d "ios/Frameworks" ]; then
    echo "❌ Warning: ios/Frameworks directory not found"
    echo "   Create it with: mkdir -p ios/Frameworks"
fi

# Check if xcframework exists
if [ ! -d "ios/Frameworks/IdentiFI-v1600.xcframework" ]; then
    echo "❌ Warning: IdentiFI xcframework not found in ios/Frameworks/"
    echo "   Copy it with: cp -R ../IdentiFI-v1600.xcframework ios/Frameworks/"
else
    echo "✅ IdentiFI xcframework found"
fi

# Check TypeScript compilation
echo "🔍 Checking TypeScript compilation..."
npx tsc --noEmit --skipLibCheck 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ TypeScript compilation successful"
else
    echo "❌ TypeScript compilation failed"
    echo "   Run 'npx tsc --noEmit' to see errors"
fi

# Check if bridging header exists
if [ ! -f "ios/IdentiFITestApp/IdentiFITestApp-Bridging-Header.h" ]; then
    echo "❌ Warning: Bridging header not found"
else
    echo "✅ Bridging header exists"
fi

# Check if native module files exist
if [ ! -f "ios/IdentiFITestApp/RNIdentiFIModule.h" ] || [ ! -f "ios/IdentiFITestApp/RNIdentiFIModule.m" ]; then
    echo "❌ Warning: Native module files not found"
else
    echo "✅ Native module files exist"
fi

echo ""
echo "🚀 Build Readiness Summary:"
echo "=========================="

# Final checks
ISSUES=0

if [ ! -d "ios/Frameworks/IdentiFI-v1600.xcframework" ]; then
    echo "❌ Missing: IdentiFI xcframework"
    ((ISSUES++))
fi

# Check if IdentiFI.h exists in the project
if [ ! -f "ios/IdentiFITestApp/IdentiFI.h" ]; then
    echo "❌ Missing: IdentiFI.h header file"
    ((ISSUES++))
fi

if [ $ISSUES -eq 0 ]; then
    echo "✅ Ready to build! Run 'npx react-native run-ios'"
    echo ""
    echo "📋 Next steps:"
    echo "1. Open ios/IdentiFITestApp.xcworkspace in Xcode"
    echo "2. Add the xcframework to your project (if not done)"
    echo "3. Configure build settings as per INTEGRATION_GUIDE.md"
    echo "4. Uncomment IdentiFI code in RNIdentiFIModule.m"
    echo "5. Build and test!"
else
    echo "⚠️  Found $ISSUES issue(s) that need attention"
    echo "   Check the warnings above and follow BUILD_GUIDE.md"
fi

echo ""
echo "📚 Documentation:"
echo "   BUILD_GUIDE.md - Complete build instructions"
echo "   INTEGRATION_GUIDE.md - Xcode integration steps"
echo "   API_DOCUMENTATION.md - SDK method documentation"