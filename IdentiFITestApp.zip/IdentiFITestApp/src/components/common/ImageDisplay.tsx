/**
 * Image Display Component
 * 
 * Displays base64 encoded images from IdentiFI SDK
 */

import React from 'react';
import { View, Image, Text, StyleSheet, Dimensions } from 'react-native';

interface ImageDisplayProps {
  base64Image?: string;
  title?: string;
  placeholder?: string;
  style?: any;
}

const { width: screenWidth } = Dimensions.get('window');

const ImageDisplay: React.FC<ImageDisplayProps> = ({
  base64Image,
  title,
  placeholder = 'No image available',
  style,
}) => {
  return (
    <View style={[styles.container, style]}>
      {title && <Text style={styles.title}>{title}</Text>}
      <View style={styles.imageContainer}>
        {base64Image ? (
          <Image
            source={{ uri: `data:image/png;base64,${base64Image}` }}
            style={styles.image}
            resizeMode="contain"
          />
        ) : (
          <View style={styles.placeholder}>
            <Text style={styles.placeholderText}>{placeholder}</Text>
          </View>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginVertical: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
    textAlign: 'center',
  },
  imageContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 200,
  },
  image: {
    width: screenWidth - 64,
    height: 200,
    borderRadius: 8,
  },
  placeholder: {
    width: screenWidth - 64,
    height: 200,
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderStyle: 'dashed',
  },
  placeholderText: {
    color: '#999',
    fontSize: 14,
    textAlign: 'center',
  },
});

export default ImageDisplay;