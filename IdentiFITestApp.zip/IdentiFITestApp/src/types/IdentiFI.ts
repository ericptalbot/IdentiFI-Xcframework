/**
 * TypeScript types for IdentiFI SDK
 */

// Device connection status
export enum ConnectionStatus {
  DISCONNECTED = 'disconnected',
  CONNECTING = 'connecting',
  CONNECTED = 'connected',
  CONNECTION_ERROR = 'connection_error',
  CONNECTION_TIMEOUT = 'connection_timeout',
}

// Fingerprint capture types
export enum FingerprintCaptureType {
  ONE_FINGER = 'one_finger',
  TWO_FINGER = 'two_finger',
  FOUR_FINGER = 'four_finger',
  ROLL_FINGER = 'roll_finger',
}

// Fingerprint capture status codes
export enum FingerprintCaptureStatus {
  STARTED = 0,
  IN_PROGRESS = 1,
  COMPLETED = 2,
  ERROR = 3,
  CANCELLED = 4,
  NFIQ_SCORE_TOO_LOW = 5,
  ROLLING_SMEAR_DETECTED = 6,
}

// Iris capture status codes
export enum IrisCaptureStatus {
  STARTED = 0,
  IN_PROGRESS = 1,
  COMPLETED = 2,
  ERROR = 3,
  CANCELLED = 4,
}

// Device information interface
export interface DeviceInfo {
  serialNumber?: string;
  firmwareVersion?: string;
  modelNumber?: string;
  description?: string;
  libraryVersion?: string;
  batteryPercentage?: number;
}

// Power status interface
export interface PowerStatus {
  fingerprintSensorPowered: boolean;
  irisSensorPowered: boolean;
  powerOffModeSeconds?: number;
}

// Settings interface
export interface DeviceSettings {
  ledBrightness?: number;
  minimumNFIQScore?: number;
  powerOffModeSeconds?: number;
}

// Fingerprint image data
export interface FingerprintImage {
  base64Data: string;
  savedAtIndex: number;
  nfiqScore?: number;
  isWSQEncoded?: boolean;
  isCropped?: boolean;
}

// Iris image data
export interface IrisImage {
  leftIrisBase64: string;
  rightIrisBase64: string;
  leftTotalScore: number;
  leftUsableArea: number;
  rightTotalScore: number;
  rightUsableArea: number;
}

// Streaming data for rolled fingerprint
export interface RolledFingerprintStream {
  base64Image: string;
  rollingState: number;
  verticalLineX: number;
}

// Device state interface
export interface DeviceState {
  connectionStatus: ConnectionStatus;
  deviceInfo: DeviceInfo;
  powerStatus: PowerStatus;
  settings: DeviceSettings;
  isCapturing: boolean;
  captureType?: FingerprintCaptureType;
  lastError?: string;
}

// Event payloads
export interface ConnectionEventPayload {
  status: ConnectionStatus;
  error?: string;
}

export interface FingerprintCaptureEventPayload {
  status: FingerprintCaptureStatus;
  captureType: FingerprintCaptureType;
  savedAtIndex?: number;
  image?: FingerprintImage;
}

export interface IrisCaptureEventPayload {
  status: IrisCaptureStatus;
  image?: IrisImage;
}

export interface StreamingEventPayload {
  image: string;
  rollingData?: RolledFingerprintStream;
}

// NFIQ Score levels (1-5, where 1 is highest quality)
export enum NFIQScoreLevel {
  EXCELLENT = 1,
  VERY_GOOD = 2,
  GOOD = 3,
  FAIR = 4,
  POOR = 5,
}

// Security levels for finger duplication check
export enum SecurityLevel {
  LOW = 1,
  MEDIUM = 2,
  HIGH = 3,
  VERY_HIGH = 4,
}

// LED control settings
export interface LEDControlSettings {
  powerLED: number;
  fpLED: number;
  comLED: number;
  irisLED: number;
  mSecOn: number;
  mSecOff: number;
}

// Firmware update result codes
export enum FirmwareUpdateResult {
  SUCCESS = 0,
  FAILED = 1,
  IN_PROGRESS = 2,
  LEGACY_MODE_REQUIRED = 3,
}

// Utility types for React components
export type FingerprintCaptureHandler = (type: FingerprintCaptureType, savedAtIndex?: number) => Promise<void>;
export type IrisCaptureHandler = () => Promise<void>;
export type DeviceConnectionHandler = () => Promise<void>;
export type SettingsUpdateHandler = (settings: Partial<DeviceSettings>) => Promise<void>;