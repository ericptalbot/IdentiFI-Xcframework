/**
 * App Navigator
 * 
 * Main navigation structure for the IdentiFI Test App
 */

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';

// Import screens
import ConnectionScreen from '../screens/ConnectionScreen';
import FingerprintScreen from '../screens/FingerprintScreen';
import IrisScreen from '../screens/IrisScreen';
import SettingsScreen from '../screens/SettingsScreen';
import DeviceInfoScreen from '../screens/DeviceInfoScreen';

const Tab = createBottomTabNavigator();

// Simple icon component (you can replace with react-native-vector-icons later)
const TabBarIcon = ({ name, focused }: { name: string; focused: boolean }) => (
  <Text style={{ fontSize: 12, color: focused ? '#007AFF' : '#999' }}>
    {name}
  </Text>
);

const AppNavigator: React.FC = () => {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          tabBarActiveTintColor: '#007AFF',
          tabBarInactiveTintColor: '#999',
          headerStyle: {
            backgroundColor: '#007AFF',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      >
        <Tab.Screen
          name="Connection"
          component={ConnectionScreen}
          options={{
            title: 'Connection',
            tabBarIcon: ({ focused }) => <TabBarIcon name="🔗" focused={focused} />,
          }}
        />
        <Tab.Screen
          name="Fingerprint"
          component={FingerprintScreen}
          options={{
            title: 'Fingerprint',
            tabBarIcon: ({ focused }) => <TabBarIcon name="👆" focused={focused} />,
          }}
        />
        <Tab.Screen
          name="Iris"
          component={IrisScreen}
          options={{
            title: 'Iris',
            tabBarIcon: ({ focused }) => <TabBarIcon name="👁" focused={focused} />,
          }}
        />
        <Tab.Screen
          name="Settings"
          component={SettingsScreen}
          options={{
            title: 'Settings',
            tabBarIcon: ({ focused }) => <TabBarIcon name="⚙️" focused={focused} />,
          }}
        />
        <Tab.Screen
          name="DeviceInfo"
          component={DeviceInfoScreen}
          options={{
            title: 'Device Info',
            tabBarIcon: ({ focused }) => <TabBarIcon name="ℹ️" focused={focused} />,
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;