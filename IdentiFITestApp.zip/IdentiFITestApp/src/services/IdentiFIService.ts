/**
 * IdentiFI Service for React Native
 * 
 * This service provides a TypeScript interface to the native IdentiFI SDK
 * It handles all communication with the native iOS bridge module
 */

import { NativeModules, NativeEventEmitter, EmitterSubscription } from 'react-native';

// Type definitions for IdentiFI events and data
export interface IdentiFIEventEmitter {
  addListener(eventType: string, listener: Function): EmitterSubscription;
  removeAllListeners(eventType: string): void;
}

export interface ConnectionEvents {
  onConnection: () => void;
  onConnectionError: (data: { error: string }) => void;
  onConnectionTimeOut: () => void;
  onDisconnection: () => void;
}

export interface FingerprintEvents {
  onCancelFpCapture: () => void;
  onFpCaptureStatus: (data: { status: number }) => void;
  onStreaming: (data: { image: string }) => void;
  onStreamingRolledFp: (data: { 
    image: string; 
    rollingState: number; 
    verticalLineX: number; 
  }) => void;
  onLastFrame: (data: { image: string; savedAtIndex: number }) => void;
  onLastFrame_RAW: (data: { rawData: string; savedAtIndex: number }) => void;
  onLastFrameRolledFp: (data: { image: string; savedAtIndex: number }) => void;
  onLastFrameRolledFp_RAW: (data: { rawData: string; savedAtIndex: number }) => void;
}

export interface IrisEvents {
  onCancelIrisCapture: () => void;
  onIrisCaptureStatus: (data: { status: number }) => void;
  onStreamingLeftIris: (data: { leftIris: string; rightIris: string }) => void;
  onLastFrameLeftIris: (data: {
    leftIris: string;
    rightIris: string;
    leftTotalScore: number;
    leftUsableArea: number;
    rightTotalScore: number;
    rightUsableArea: number;
  }) => void;
}

export interface DeviceEvents {
  onGetBatteryPercentage: (data: { percentage: number }) => void;
  onGetDeviceSerialNumber: (data: { serialNumber: string }) => void;
  onGetFirmwareVersion: (data: { version: string }) => void;
  onGetModelNumber: (data: { model: string }) => void;
  onGetReaderDescription: (data: { description: string }) => void;
}

export interface SettingsEvents {
  onGetLEDBrightness: (data: { brightness: number }) => void;
  onSetLEDBrightness: (data: { brightness: number }) => void;
  onSetMinimumNFIQScore: (data: { score: number }) => void;
}

export interface SavedImageEvents {
  onGetNfiqScore: (data: { score: number; savedAtIndex: number }) => void;
  onGetSegmentedFpImage_RAW: (data: { rawData: string; savedAtIndex: number }) => void;
  onGetWSQEncodedFpImage: (data: { wsqData: string; savedAtIndex: number }) => void;
  onIsFingerDuplicated: (data: { isDuplicated: number }) => void;
  onSavedFpImagesCleared: (data: { savedAtIndex: number }) => void;
}

export interface PowerEvents {
  onGetPowerOffMode: (data: { seconds: number }) => void;
  onSetPowerOffMode: (data: { seconds: number }) => void;
  onGetFpPowerStatus: (data: { status: boolean }) => void;
  onSetFpPowerOn: (data: { status: boolean }) => void;
  onSetFpPowerOff: () => void;
  onGetIrisPowerStatus: (data: { status: boolean }) => void;
  onSetIrisPowerOn: (data: { status: boolean }) => void;
  onSetIrisPowerOff: () => void;
}

export type IdentiFIEvents = ConnectionEvents & 
  FingerprintEvents & 
  IrisEvents & 
  DeviceEvents & 
  SettingsEvents & 
  SavedImageEvents & 
  PowerEvents;

// Native module interface
interface RNIdentiFIModule {
  // Connection methods
  connect(): Promise<string>;
  disconnect(): Promise<string>;

  // Fingerprint capture methods
  startCaptureOneFinger(savedAtIndex: number): Promise<string>;
  startCaptureTwoFinger(savedAtIndex: number): Promise<string>;
  startCaptureFourFinger(savedAtIndex: number): Promise<string>;
  startCaptureRollFinger(savedAtIndex: number): Promise<string>;
  cancelFpCapture(): Promise<string>;

  // Iris capture methods
  startCaptureIris(): Promise<string>;
  cancelIrisCapture(): Promise<string>;

  // Device information methods
  getBatteryPercentage(): Promise<string>;
  getDeviceSerialNumber(): Promise<string>;
  getFirmwareVersion(): Promise<string>;
  getLibraryVersion(): Promise<string>;
  getModelNumber(): Promise<string>;
  getReaderDescription(): Promise<string>;

  // Settings methods
  setLEDBrightness(brightness: number): Promise<string>;
  getLEDBrightness(): Promise<string>;
  setMinimumNFIQScore(score: number): Promise<string>;

  // Power management methods
  setFpPowerOn(): Promise<string>;
  setFpPowerOff(): Promise<string>;
  getFpPowerStatus(): Promise<string>;
  setIrisPowerOn(): Promise<string>;
  setIrisPowerOff(): Promise<string>;
  getIrisPowerStatus(): Promise<string>;

  // Saved images methods
  clearSavedFpImages(savedAtIndex: number): Promise<string>;
  getNfiqScoreFromImageSavedAt(savedAtIndex: number): Promise<string>;
  getSegmentedFpImageSavedAt(savedAtIndex: number): Promise<string>;
  getWSQEncodedFpImageFromImageSavedAt(savedAtIndex: number, croppedImage: boolean): Promise<string>;
  isFingerDuplicated(savedAtIndex: number, securityLevel: number): Promise<string>;
}

/**
 * IdentiFI Service Class
 * 
 * Provides a high-level TypeScript interface to interact with the IdentiFI SDK
 */
class IdentiFIService {
  private nativeModule: RNIdentiFIModule;
  private eventEmitter: IdentiFIEventEmitter;
  private eventSubscriptions: Map<string, EmitterSubscription> = new Map();

  constructor() {
    const { RNIdentiFIModule } = NativeModules;
    
    if (!RNIdentiFIModule) {
      throw new Error('RNIdentiFIModule is not available. Make sure the native module is properly installed.');
    }

    this.nativeModule = RNIdentiFIModule;
    this.eventEmitter = new NativeEventEmitter(RNIdentiFIModule);
  }

  // Event subscription methods
  addEventListener<K extends keyof IdentiFIEvents>(
    eventName: K,
    listener: IdentiFIEvents[K]
  ): EmitterSubscription {
    const subscription = this.eventEmitter.addListener(eventName as string, listener);
    this.eventSubscriptions.set(eventName as string, subscription);
    return subscription;
  }

  removeEventListener(eventName: keyof IdentiFIEvents): void {
    const subscription = this.eventSubscriptions.get(eventName as string);
    if (subscription) {
      subscription.remove();
      this.eventSubscriptions.delete(eventName as string);
    }
  }

  removeAllEventListeners(): void {
    this.eventSubscriptions.forEach((subscription) => {
      subscription.remove();
    });
    this.eventSubscriptions.clear();
  }

  // Connection methods
  async connect(): Promise<string> {
    try {
      return await this.nativeModule.connect();
    } catch (error) {
      throw new Error(`Failed to connect: ${error}`);
    }
  }

  async disconnect(): Promise<string> {
    try {
      return await this.nativeModule.disconnect();
    } catch (error) {
      throw new Error(`Failed to disconnect: ${error}`);
    }
  }

  // Fingerprint capture methods
  async startCaptureOneFinger(savedAtIndex: number = 0): Promise<string> {
    try {
      return await this.nativeModule.startCaptureOneFinger(savedAtIndex);
    } catch (error) {
      throw new Error(`Failed to start one finger capture: ${error}`);
    }
  }

  async startCaptureTwoFinger(savedAtIndex: number = 0): Promise<string> {
    try {
      return await this.nativeModule.startCaptureTwoFinger(savedAtIndex);
    } catch (error) {
      throw new Error(`Failed to start two finger capture: ${error}`);
    }
  }

  async startCaptureFourFinger(savedAtIndex: number = 0): Promise<string> {
    try {
      return await this.nativeModule.startCaptureFourFinger(savedAtIndex);
    } catch (error) {
      throw new Error(`Failed to start four finger capture: ${error}`);
    }
  }

  async startCaptureRollFinger(savedAtIndex: number = 0): Promise<string> {
    try {
      return await this.nativeModule.startCaptureRollFinger(savedAtIndex);
    } catch (error) {
      throw new Error(`Failed to start roll finger capture: ${error}`);
    }
  }

  async cancelFpCapture(): Promise<string> {
    try {
      return await this.nativeModule.cancelFpCapture();
    } catch (error) {
      throw new Error(`Failed to cancel fingerprint capture: ${error}`);
    }
  }

  // Iris capture methods
  async startCaptureIris(): Promise<string> {
    try {
      return await this.nativeModule.startCaptureIris();
    } catch (error) {
      throw new Error(`Failed to start iris capture: ${error}`);
    }
  }

  async cancelIrisCapture(): Promise<string> {
    try {
      return await this.nativeModule.cancelIrisCapture();
    } catch (error) {
      throw new Error(`Failed to cancel iris capture: ${error}`);
    }
  }

  // Device information methods
  async getBatteryPercentage(): Promise<string> {
    try {
      return await this.nativeModule.getBatteryPercentage();
    } catch (error) {
      throw new Error(`Failed to get battery percentage: ${error}`);
    }
  }

  async getDeviceSerialNumber(): Promise<string> {
    try {
      return await this.nativeModule.getDeviceSerialNumber();
    } catch (error) {
      throw new Error(`Failed to get device serial number: ${error}`);
    }
  }

  async getFirmwareVersion(): Promise<string> {
    try {
      return await this.nativeModule.getFirmwareVersion();
    } catch (error) {
      throw new Error(`Failed to get firmware version: ${error}`);
    }
  }

  async getLibraryVersion(): Promise<string> {
    try {
      return await this.nativeModule.getLibraryVersion();
    } catch (error) {
      throw new Error(`Failed to get library version: ${error}`);
    }
  }

  async getModelNumber(): Promise<string> {
    try {
      return await this.nativeModule.getModelNumber();
    } catch (error) {
      throw new Error(`Failed to get model number: ${error}`);
    }
  }

  async getReaderDescription(): Promise<string> {
    try {
      return await this.nativeModule.getReaderDescription();
    } catch (error) {
      throw new Error(`Failed to get reader description: ${error}`);
    }
  }

  // Settings methods
  async setLEDBrightness(brightness: number): Promise<string> {
    try {
      return await this.nativeModule.setLEDBrightness(brightness);
    } catch (error) {
      throw new Error(`Failed to set LED brightness: ${error}`);
    }
  }

  async getLEDBrightness(): Promise<string> {
    try {
      return await this.nativeModule.getLEDBrightness();
    } catch (error) {
      throw new Error(`Failed to get LED brightness: ${error}`);
    }
  }

  async setMinimumNFIQScore(score: number): Promise<string> {
    try {
      return await this.nativeModule.setMinimumNFIQScore(score);
    } catch (error) {
      throw new Error(`Failed to set minimum NFIQ score: ${error}`);
    }
  }

  // Power management methods
  async setFpPowerOn(): Promise<string> {
    try {
      return await this.nativeModule.setFpPowerOn();
    } catch (error) {
      throw new Error(`Failed to power on fingerprint sensor: ${error}`);
    }
  }

  async setFpPowerOff(): Promise<string> {
    try {
      return await this.nativeModule.setFpPowerOff();
    } catch (error) {
      throw new Error(`Failed to power off fingerprint sensor: ${error}`);
    }
  }

  async getFpPowerStatus(): Promise<string> {
    try {
      return await this.nativeModule.getFpPowerStatus();
    } catch (error) {
      throw new Error(`Failed to get fingerprint power status: ${error}`);
    }
  }

  async setIrisPowerOn(): Promise<string> {
    try {
      return await this.nativeModule.setIrisPowerOn();
    } catch (error) {
      throw new Error(`Failed to power on iris sensor: ${error}`);
    }
  }

  async setIrisPowerOff(): Promise<string> {
    try {
      return await this.nativeModule.setIrisPowerOff();
    } catch (error) {
      throw new Error(`Failed to power off iris sensor: ${error}`);
    }
  }

  async getIrisPowerStatus(): Promise<string> {
    try {
      return await this.nativeModule.getIrisPowerStatus();
    } catch (error) {
      throw new Error(`Failed to get iris power status: ${error}`);
    }
  }

  // Saved images methods
  async clearSavedFpImages(savedAtIndex: number): Promise<string> {
    try {
      return await this.nativeModule.clearSavedFpImages(savedAtIndex);
    } catch (error) {
      throw new Error(`Failed to clear saved FP images: ${error}`);
    }
  }

  async getNfiqScoreFromImageSavedAt(savedAtIndex: number): Promise<string> {
    try {
      return await this.nativeModule.getNfiqScoreFromImageSavedAt(savedAtIndex);
    } catch (error) {
      throw new Error(`Failed to get NFIQ score: ${error}`);
    }
  }

  async getSegmentedFpImageSavedAt(savedAtIndex: number): Promise<string> {
    try {
      return await this.nativeModule.getSegmentedFpImageSavedAt(savedAtIndex);
    } catch (error) {
      throw new Error(`Failed to get segmented FP image: ${error}`);
    }
  }

  async getWSQEncodedFpImageFromImageSavedAt(
    savedAtIndex: number, 
    croppedImage: boolean = false
  ): Promise<string> {
    try {
      return await this.nativeModule.getWSQEncodedFpImageFromImageSavedAt(savedAtIndex, croppedImage);
    } catch (error) {
      throw new Error(`Failed to get WSQ encoded FP image: ${error}`);
    }
  }

  async isFingerDuplicated(savedAtIndex: number, securityLevel: number = 3): Promise<string> {
    try {
      return await this.nativeModule.isFingerDuplicated(savedAtIndex, securityLevel);
    } catch (error) {
      throw new Error(`Failed to check finger duplication: ${error}`);
    }
  }
}

// Export singleton instance
export default new IdentiFIService();