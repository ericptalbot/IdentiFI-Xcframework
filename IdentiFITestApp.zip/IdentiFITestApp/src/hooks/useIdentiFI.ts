/**
 * React Hook for IdentiFI SDK
 * 
 * Custom hook that manages IdentiFI device state and provides
 * convenient methods for interacting with the device
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import IdentiFIService from '../services/IdentiFIService';
import {
  DeviceState,
  ConnectionStatus,
  FingerprintCaptureType,
  FingerprintCaptureStatus,
  IrisCaptureStatus,
  DeviceInfo,
  PowerStatus,
  DeviceSettings,
  FingerprintImage,
  IrisImage,
  StreamingEventPayload,
} from '../types/IdentiFI';

interface UseIdentiFIReturn {
  // State
  deviceState: DeviceState;
  isConnected: boolean;
  isConnecting: boolean;
  isCapturing: boolean;
  
  // Connection methods
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  
  // Fingerprint capture methods
  startCaptureOneFinger: (savedAtIndex?: number) => Promise<void>;
  startCaptureTwoFinger: (savedAtIndex?: number) => Promise<void>;
  startCaptureFourFinger: (savedAtIndex?: number) => Promise<void>;
  startCaptureRollFinger: (savedAtIndex?: number) => Promise<void>;
  cancelFpCapture: () => Promise<void>;
  
  // Iris capture methods
  startCaptureIris: () => Promise<void>;
  cancelIrisCapture: () => Promise<void>;
  
  // Device information methods
  refreshDeviceInfo: () => Promise<void>;
  
  // Power management methods
  setFpPowerOn: () => Promise<void>;
  setFpPowerOff: () => Promise<void>;
  setIrisPowerOn: () => Promise<void>;
  setIrisPowerOff: () => Promise<void>;
  getFpPowerStatus: () => Promise<void>;
  getIrisPowerStatus: () => Promise<void>;
  refreshPowerStatus: () => Promise<void>;
  
  // Settings methods
  setLEDBrightness: (brightness: number) => Promise<void>;
  getLEDBrightness: () => Promise<void>;
  setMinimumNFIQScore: (score: number) => Promise<void>;
  refreshSettings: () => Promise<void>;
  
  // Saved images methods
  clearSavedFpImages: (savedAtIndex: number) => Promise<void>;
  getNfiqScore: (savedAtIndex: number) => Promise<void>;
  getWSQEncodedImage: (savedAtIndex: number, cropped?: boolean) => Promise<void>;
  checkFingerDuplication: (savedAtIndex: number, securityLevel?: number) => Promise<void>;
  
  // Streaming data
  streamingImage: string | null;
  lastCapturedImage: FingerprintImage | null;
  lastIrisImage: IrisImage | null;
}

const initialDeviceState: DeviceState = {
  connectionStatus: ConnectionStatus.DISCONNECTED,
  deviceInfo: {},
  powerStatus: {
    fingerprintSensorPowered: false,
    irisSensorPowered: false,
  },
  settings: {},
  isCapturing: false,
};

export const useIdentiFI = (): UseIdentiFIReturn => {
  const [deviceState, setDeviceState] = useState<DeviceState>(initialDeviceState);
  const [streamingImage, setStreamingImage] = useState<string | null>(null);
  const [lastCapturedImage, setLastCapturedImage] = useState<FingerprintImage | null>(null);
  const [lastIrisImage, setLastIrisImage] = useState<IrisImage | null>(null);
  
  const subscriptionsRef = useRef<Array<{ remove: () => void }>>([]);

  // Setup event listeners
  useEffect(() => {
    const setupEventListeners = () => {
      // Connection events
      const connectionSub = IdentiFIService.addEventListener('onConnection', () => {
        setDeviceState(prev => ({
          ...prev,
          connectionStatus: ConnectionStatus.CONNECTED,
          lastError: undefined,
        }));
      });
      
      const connectionErrorSub = IdentiFIService.addEventListener('onConnectionError', ({ error }) => {
        setDeviceState(prev => ({
          ...prev,
          connectionStatus: ConnectionStatus.CONNECTION_ERROR,
          lastError: error,
        }));
      });
      
      const connectionTimeoutSub = IdentiFIService.addEventListener('onConnectionTimeOut', () => {
        setDeviceState(prev => ({
          ...prev,
          connectionStatus: ConnectionStatus.CONNECTION_TIMEOUT,
          lastError: 'Connection timeout',
        }));
      });
      
      const disconnectionSub = IdentiFIService.addEventListener('onDisconnection', () => {
        setDeviceState(prev => ({
          ...prev,
          connectionStatus: ConnectionStatus.DISCONNECTED,
          isCapturing: false,
        }));
      });

      // Fingerprint capture events
      const cancelFpCaptureSub = IdentiFIService.addEventListener('onCancelFpCapture', () => {
        setDeviceState(prev => ({
          ...prev,
          isCapturing: false,
          captureType: undefined,
        }));
        setStreamingImage(null);
      });
      
      const fpCaptureStatusSub = IdentiFIService.addEventListener('onFpCaptureStatus', ({ status }) => {
        const isCapturing = status === FingerprintCaptureStatus.IN_PROGRESS || 
                           status === FingerprintCaptureStatus.STARTED;
        
        setDeviceState(prev => ({
          ...prev,
          isCapturing,
          captureType: isCapturing ? prev.captureType : undefined,
        }));
      });
      
      const streamingSub = IdentiFIService.addEventListener('onStreaming', ({ image }) => {
        setStreamingImage(image);
      });
      
      const lastFrameSub = IdentiFIService.addEventListener('onLastFrame', ({ image, savedAtIndex }) => {
        const fingerprintImage: FingerprintImage = {
          base64Data: image,
          savedAtIndex,
        };
        setLastCapturedImage(fingerprintImage);
        setDeviceState(prev => ({
          ...prev,
          isCapturing: false,
          captureType: undefined,
        }));
        setStreamingImage(null);
      });

      // Iris capture events
      const cancelIrisCaptureSub = IdentiFIService.addEventListener('onCancelIrisCapture', () => {
        setDeviceState(prev => ({
          ...prev,
          isCapturing: false,
        }));
      });
      
      const irisCaptureStatusSub = IdentiFIService.addEventListener('onIrisCaptureStatus', ({ status }) => {
        const isCapturing = status === IrisCaptureStatus.IN_PROGRESS || 
                           status === IrisCaptureStatus.STARTED;
        
        setDeviceState(prev => ({
          ...prev,
          isCapturing,
        }));
      });
      
      const lastFrameIrisSub = IdentiFIService.addEventListener('onLastFrameLeftIris', (data) => {
        const irisImage: IrisImage = {
          leftIrisBase64: data.leftIris,
          rightIrisBase64: data.rightIris,
          leftTotalScore: data.leftTotalScore,
          leftUsableArea: data.leftUsableArea,
          rightTotalScore: data.rightTotalScore,
          rightUsableArea: data.rightUsableArea,
        };
        setLastIrisImage(irisImage);
        setDeviceState(prev => ({
          ...prev,
          isCapturing: false,
        }));
      });

      // Device information events
      const batteryPercentageSub = IdentiFIService.addEventListener('onGetBatteryPercentage', ({ percentage }) => {
        setDeviceState(prev => ({
          ...prev,
          deviceInfo: {
            ...prev.deviceInfo,
            batteryPercentage: percentage,
          },
        }));
      });
      
      const serialNumberSub = IdentiFIService.addEventListener('onGetDeviceSerialNumber', ({ serialNumber }) => {
        setDeviceState(prev => ({
          ...prev,
          deviceInfo: {
            ...prev.deviceInfo,
            serialNumber,
          },
        }));
      });
      
      const firmwareVersionSub = IdentiFIService.addEventListener('onGetFirmwareVersion', ({ version }) => {
        setDeviceState(prev => ({
          ...prev,
          deviceInfo: {
            ...prev.deviceInfo,
            firmwareVersion: version,
          },
        }));
      });
      
      const modelNumberSub = IdentiFIService.addEventListener('onGetModelNumber', ({ model }) => {
        setDeviceState(prev => ({
          ...prev,
          deviceInfo: {
            ...prev.deviceInfo,
            modelNumber: model,
          },
        }));
      });

      // Store subscriptions for cleanup
      subscriptionsRef.current = [
        connectionSub,
        connectionErrorSub, 
        connectionTimeoutSub,
        disconnectionSub,
        cancelFpCaptureSub,
        fpCaptureStatusSub,
        streamingSub,
        lastFrameSub,
        cancelIrisCaptureSub,
        irisCaptureStatusSub,
        lastFrameIrisSub,
        batteryPercentageSub,
        serialNumberSub,
        firmwareVersionSub,
        modelNumberSub,
      ];
    };

    setupEventListeners();

    // Cleanup function
    return () => {
      subscriptionsRef.current.forEach(sub => sub.remove());
      subscriptionsRef.current = [];
    };
  }, []);

  // Connection methods
  const connect = useCallback(async () => {
    try {
      setDeviceState(prev => ({
        ...prev,
        connectionStatus: ConnectionStatus.CONNECTING,
        lastError: undefined,
      }));
      
      await IdentiFIService.connect();
    } catch (error) {
      setDeviceState(prev => ({
        ...prev,
        connectionStatus: ConnectionStatus.CONNECTION_ERROR,
        lastError: error instanceof Error ? error.message : 'Unknown error',
      }));
      throw error;
    }
  }, []);

  const disconnect = useCallback(async () => {
    try {
      await IdentiFIService.disconnect();
    } catch (error) {
      console.error('Error disconnecting:', error);
      throw error;
    }
  }, []);

  // Fingerprint capture methods
  const startCaptureOneFinger = useCallback(async (savedAtIndex = 0) => {
    try {
      setDeviceState(prev => ({
        ...prev,
        isCapturing: true,
        captureType: FingerprintCaptureType.ONE_FINGER,
      }));
      setStreamingImage(null);
      setLastCapturedImage(null);
      
      await IdentiFIService.startCaptureOneFinger(savedAtIndex);
    } catch (error) {
      setDeviceState(prev => ({
        ...prev,
        isCapturing: false,
        captureType: undefined,
        lastError: error instanceof Error ? error.message : 'Unknown error',
      }));
      throw error;
    }
  }, []);

  const startCaptureTwoFinger = useCallback(async (savedAtIndex = 0) => {
    try {
      setDeviceState(prev => ({
        ...prev,
        isCapturing: true,
        captureType: FingerprintCaptureType.TWO_FINGER,
      }));
      setStreamingImage(null);
      setLastCapturedImage(null);
      
      await IdentiFIService.startCaptureTwoFinger(savedAtIndex);
    } catch (error) {
      setDeviceState(prev => ({
        ...prev,
        isCapturing: false,
        captureType: undefined,
        lastError: error instanceof Error ? error.message : 'Unknown error',
      }));
      throw error;
    }
  }, []);

  const startCaptureFourFinger = useCallback(async (savedAtIndex = 0) => {
    try {
      setDeviceState(prev => ({
        ...prev,
        isCapturing: true,
        captureType: FingerprintCaptureType.FOUR_FINGER,
      }));
      setStreamingImage(null);
      setLastCapturedImage(null);
      
      await IdentiFIService.startCaptureFourFinger(savedAtIndex);
    } catch (error) {
      setDeviceState(prev => ({
        ...prev,
        isCapturing: false,
        captureType: undefined,
        lastError: error instanceof Error ? error.message : 'Unknown error',
      }));
      throw error;
    }
  }, []);

  const startCaptureRollFinger = useCallback(async (savedAtIndex = 0) => {
    try {
      setDeviceState(prev => ({
        ...prev,
        isCapturing: true,
        captureType: FingerprintCaptureType.ROLL_FINGER,
      }));
      setStreamingImage(null);
      setLastCapturedImage(null);
      
      await IdentiFIService.startCaptureRollFinger(savedAtIndex);
    } catch (error) {
      setDeviceState(prev => ({
        ...prev,
        isCapturing: false,
        captureType: undefined,
        lastError: error instanceof Error ? error.message : 'Unknown error',
      }));
      throw error;
    }
  }, []);

  const cancelFpCapture = useCallback(async () => {
    try {
      await IdentiFIService.cancelFpCapture();
    } catch (error) {
      console.error('Error cancelling fingerprint capture:', error);
      throw error;
    }
  }, []);

  // Iris capture methods
  const startCaptureIris = useCallback(async () => {
    try {
      setDeviceState(prev => ({
        ...prev,
        isCapturing: true,
      }));
      setLastIrisImage(null);
      
      await IdentiFIService.startCaptureIris();
    } catch (error) {
      setDeviceState(prev => ({
        ...prev,
        isCapturing: false,
        lastError: error instanceof Error ? error.message : 'Unknown error',
      }));
      throw error;
    }
  }, []);

  const cancelIrisCapture = useCallback(async () => {
    try {
      await IdentiFIService.cancelIrisCapture();
    } catch (error) {
      console.error('Error cancelling iris capture:', error);
      throw error;
    }
  }, []);

  // Device information methods
  const refreshDeviceInfo = useCallback(async () => {
    try {
      await Promise.all([
        IdentiFIService.getBatteryPercentage(),
        IdentiFIService.getDeviceSerialNumber(),
        IdentiFIService.getFirmwareVersion(),
        IdentiFIService.getModelNumber(),
        IdentiFIService.getReaderDescription(),
      ]);
    } catch (error) {
      console.error('Error refreshing device info:', error);
      throw error;
    }
  }, []);

  // Power management methods
  const setFpPowerOn = useCallback(async () => {
    try {
      await IdentiFIService.setFpPowerOn();
    } catch (error) {
      console.error('Error setting FP power on:', error);
      throw error;
    }
  }, []);

  const setFpPowerOff = useCallback(async () => {
    try {
      await IdentiFIService.setFpPowerOff();
    } catch (error) {
      console.error('Error setting FP power off:', error);
      throw error;
    }
  }, []);

  const setIrisPowerOn = useCallback(async () => {
    try {
      await IdentiFIService.setIrisPowerOn();
    } catch (error) {
      console.error('Error setting iris power on:', error);
      throw error;
    }
  }, []);

  const setIrisPowerOff = useCallback(async () => {
    try {
      await IdentiFIService.setIrisPowerOff();
    } catch (error) {
      console.error('Error setting iris power off:', error);
      throw error;
    }
  }, []);

  const getIrisPowerStatus = useCallback(async () => {
    try {
      await IdentiFIService.getIrisPowerStatus();
    } catch (error) {
      console.error('Error getting iris power status:', error);
      throw error;
    }
  }, []);

  const getFpPowerStatus = useCallback(async () => {
    try {
      await IdentiFIService.getFpPowerStatus();
    } catch (error) {
      console.error('Error getting FP power status:', error);
      throw error;
    }
  }, []);

  const refreshPowerStatus = useCallback(async () => {
    try {
      await Promise.all([
        IdentiFIService.getFpPowerStatus(),
        IdentiFIService.getIrisPowerStatus(),
      ]);
    } catch (error) {
      console.error('Error refreshing power status:', error);
      throw error;
    }
  }, []);

  // Settings methods
  const setLEDBrightness = useCallback(async (brightness: number) => {
    try {
      await IdentiFIService.setLEDBrightness(brightness);
    } catch (error) {
      console.error('Error setting LED brightness:', error);
      throw error;
    }
  }, []);

  const getLEDBrightness = useCallback(async () => {
    try {
      await IdentiFIService.getLEDBrightness();
    } catch (error) {
      console.error('Error getting LED brightness:', error);
      throw error;
    }
  }, []);

  const setMinimumNFIQScore = useCallback(async (score: number) => {
    try {
      await IdentiFIService.setMinimumNFIQScore(score);
    } catch (error) {
      console.error('Error setting minimum NFIQ score:', error);
      throw error;
    }
  }, []);

  const refreshSettings = useCallback(async () => {
    try {
      await IdentiFIService.getLEDBrightness();
    } catch (error) {
      console.error('Error refreshing settings:', error);
      throw error;
    }
  }, []);

  // Saved images methods
  const clearSavedFpImages = useCallback(async (savedAtIndex: number) => {
    try {
      await IdentiFIService.clearSavedFpImages(savedAtIndex);
    } catch (error) {
      console.error('Error clearing saved FP images:', error);
      throw error;
    }
  }, []);

  const getNfiqScore = useCallback(async (savedAtIndex: number) => {
    try {
      await IdentiFIService.getNfiqScoreFromImageSavedAt(savedAtIndex);
    } catch (error) {
      console.error('Error getting NFIQ score:', error);
      throw error;
    }
  }, []);

  const getWSQEncodedImage = useCallback(async (savedAtIndex: number, cropped = false) => {
    try {
      await IdentiFIService.getWSQEncodedFpImageFromImageSavedAt(savedAtIndex, cropped);
    } catch (error) {
      console.error('Error getting WSQ encoded image:', error);
      throw error;
    }
  }, []);

  const checkFingerDuplication = useCallback(async (savedAtIndex: number, securityLevel = 3) => {
    try {
      await IdentiFIService.isFingerDuplicated(savedAtIndex, securityLevel);
    } catch (error) {
      console.error('Error checking finger duplication:', error);
      throw error;
    }
  }, []);

  // Computed values
  const isConnected = deviceState.connectionStatus === ConnectionStatus.CONNECTED;
  const isConnecting = deviceState.connectionStatus === ConnectionStatus.CONNECTING;
  const isCapturing = deviceState.isCapturing;

  return {
    // State
    deviceState,
    isConnected,
    isConnecting,
    isCapturing,
    
    // Connection methods
    connect,
    disconnect,
    
    // Fingerprint capture methods
    startCaptureOneFinger,
    startCaptureTwoFinger,
    startCaptureFourFinger,
    startCaptureRollFinger,
    cancelFpCapture,
    
    // Iris capture methods
    startCaptureIris,
    cancelIrisCapture,
    
    // Device information methods
    refreshDeviceInfo,
    
    // Power management methods
    setFpPowerOn,
    setFpPowerOff,
    setIrisPowerOn,
    setIrisPowerOff,
    getFpPowerStatus,
    getIrisPowerStatus,
    refreshPowerStatus,
    
    // Settings methods
    setLEDBrightness,
    getLEDBrightness,
    setMinimumNFIQScore,
    refreshSettings,
    
    // Saved images methods
    clearSavedFpImages,
    getNfiqScore,
    getWSQEncodedImage,
    checkFingerDuplication,
    
    // Streaming data
    streamingImage,
    lastCapturedImage,
    lastIrisImage,
  };
};