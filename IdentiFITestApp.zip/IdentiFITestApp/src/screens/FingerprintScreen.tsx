/**
 * Fingerprint Screen
 * 
 * Screen for fingerprint capture operations
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Alert,
  TextInput,
} from 'react-native';
import { useIdentiFI } from '../hooks/useIdentiFI';
import { FingerprintCaptureType } from '../types/IdentiFI';
import Button from '../components/common/Button';
import StatusCard from '../components/common/StatusCard';
import ImageDisplay from '../components/common/ImageDisplay';

const FingerprintScreen: React.FC = () => {
  const {
    deviceState,
    isConnected,
    isCapturing,
    streamingImage,
    lastCapturedImage,
    startCaptureOneFinger,
    startCaptureTwoFinger,
    startCaptureFourFinger,
    startCaptureRollFinger,
    cancelFpCapture,
    clearSavedFpImages,
    getNfiqScore,
    getWSQEncodedImage,
    checkFingerDuplication,
  } = useIdentiFI();

  const [savedAtIndex, setSavedAtIndex] = useState('0');
  const [securityLevel, setSecurityLevel] = useState('3');

  const handleCaptureStart = async (captureType: FingerprintCaptureType) => {
    if (!isConnected) {
      Alert.alert('Not Connected', 'Please connect to the device first');
      return;
    }

    const index = parseInt(savedAtIndex, 10);
    if (isNaN(index) || index < 0 || index > 9) {
      Alert.alert('Invalid Index', 'Please enter a valid index (0-9)');
      return;
    }

    try {
      switch (captureType) {
        case FingerprintCaptureType.ONE_FINGER:
          await startCaptureOneFinger(index);
          break;
        case FingerprintCaptureType.TWO_FINGER:
          await startCaptureTwoFinger(index);
          break;
        case FingerprintCaptureType.FOUR_FINGER:
          await startCaptureFourFinger(index);
          break;
        case FingerprintCaptureType.ROLL_FINGER:
          await startCaptureRollFinger(index);
          break;
      }
    } catch (error) {
      Alert.alert(
        'Capture Error',
        error instanceof Error ? error.message : 'Failed to start capture',
        [{ text: 'OK' }]
      );
    }
  };

  const handleCancelCapture = async () => {
    try {
      await cancelFpCapture();
    } catch (error) {
      Alert.alert(
        'Cancel Error',
        error instanceof Error ? error.message : 'Failed to cancel capture',
        [{ text: 'OK' }]
      );
    }
  };

  const handleClearImages = async () => {
    const index = parseInt(savedAtIndex, 10);
    if (isNaN(index) || index < 0 || index > 9) {
      Alert.alert('Invalid Index', 'Please enter a valid index (0-9)');
      return;
    }

    try {
      await clearSavedFpImages(index);
      Alert.alert('Success', `Cleared saved images at index ${index}`);
    } catch (error) {
      Alert.alert(
        'Clear Error',
        error instanceof Error ? error.message : 'Failed to clear images',
        [{ text: 'OK' }]
      );
    }
  };

  const handleGetNfiqScore = async () => {
    const index = parseInt(savedAtIndex, 10);
    if (isNaN(index) || index < 0 || index > 9) {
      Alert.alert('Invalid Index', 'Please enter a valid index (0-9)');
      return;
    }

    try {
      await getNfiqScore(index);
    } catch (error) {
      Alert.alert(
        'NFIQ Error',
        error instanceof Error ? error.message : 'Failed to get NFIQ score',
        [{ text: 'OK' }]
      );
    }
  };

  const handleGetWSQImage = async () => {
    const index = parseInt(savedAtIndex, 10);
    if (isNaN(index) || index < 0 || index > 9) {
      Alert.alert('Invalid Index', 'Please enter a valid index (0-9)');
      return;
    }

    try {
      await getWSQEncodedImage(index, false);
    } catch (error) {
      Alert.alert(
        'WSQ Error',
        error instanceof Error ? error.message : 'Failed to get WSQ image',
        [{ text: 'OK' }]
      );
    }
  };

  const handleCheckDuplication = async () => {
    const index = parseInt(savedAtIndex, 10);
    const level = parseInt(securityLevel, 10);
    
    if (isNaN(index) || index < 0 || index > 9) {
      Alert.alert('Invalid Index', 'Please enter a valid index (0-9)');
      return;
    }
    
    if (isNaN(level) || level < 1 || level > 4) {
      Alert.alert('Invalid Security Level', 'Please enter a valid security level (1-4)');
      return;
    }

    try {
      await checkFingerDuplication(index, level);
    } catch (error) {
      Alert.alert(
        'Duplication Check Error',
        error instanceof Error ? error.message : 'Failed to check duplication',
        [{ text: 'OK' }]
      );
    }
  };

  const getCaptureStatusText = (): string => {
    if (!isConnected) return 'Device not connected';
    if (isCapturing) {
      return `Capturing ${deviceState.captureType?.replace('_', ' ') || 'fingerprint'}...`;
    }
    return 'Ready for capture';
  };

  const getCaptureStatusType = (): 'success' | 'warning' | 'error' | 'info' => {
    if (!isConnected) return 'error';
    if (isCapturing) return 'info';
    return 'success';
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.headerTitle}>Fingerprint Capture</Text>
        <Text style={styles.headerSubtitle}>
          Capture and manage fingerprint images
        </Text>

        {/* Capture Status */}
        <StatusCard
          title="Capture Status"
          status={getCaptureStatusText()}
          statusType={getCaptureStatusType()}
        />

        {/* Settings Input */}
        <View style={styles.inputSection}>
          <Text style={styles.sectionTitle}>Capture Settings</Text>
          <View style={styles.inputRow}>
            <Text style={styles.inputLabel}>Saved At Index (0-9):</Text>
            <TextInput
              style={styles.textInput}
              value={savedAtIndex}
              onChangeText={setSavedAtIndex}
              keyboardType="numeric"
              maxLength={1}
            />
          </View>
          <View style={styles.inputRow}>
            <Text style={styles.inputLabel}>Security Level (1-4):</Text>
            <TextInput
              style={styles.textInput}
              value={securityLevel}
              onChangeText={setSecurityLevel}
              keyboardType="numeric"
              maxLength={1}
            />
          </View>
        </View>

        {/* Capture Controls */}
        <View style={styles.captureSection}>
          <Text style={styles.sectionTitle}>Capture Options</Text>
          <View style={styles.buttonGrid}>
            <Button
              title="One Finger"
              onPress={() => handleCaptureStart(FingerprintCaptureType.ONE_FINGER)}
              disabled={!isConnected || isCapturing}
              style={styles.gridButton}
            />
            <Button
              title="Two Fingers"
              onPress={() => handleCaptureStart(FingerprintCaptureType.TWO_FINGER)}
              disabled={!isConnected || isCapturing}
              style={styles.gridButton}
            />
            <Button
              title="Four Fingers"
              onPress={() => handleCaptureStart(FingerprintCaptureType.FOUR_FINGER)}
              disabled={!isConnected || isCapturing}
              style={styles.gridButton}
            />
            <Button
              title="Roll Finger"
              onPress={() => handleCaptureStart(FingerprintCaptureType.ROLL_FINGER)}
              disabled={!isConnected || isCapturing}
              style={styles.gridButton}
            />
          </View>

          {isCapturing && (
            <Button
              title="Cancel Capture"
              onPress={handleCancelCapture}
              variant="danger"
              style={styles.cancelButton}
            />
          )}
        </View>

        {/* Image Display */}
        {(streamingImage || lastCapturedImage) && (
          <View style={styles.imageSection}>
            <Text style={styles.sectionTitle}>Captured Images</Text>
            
            {streamingImage && (
              <ImageDisplay
                base64Image={streamingImage}
                title="Live Preview"
                placeholder="Waiting for image stream..."
              />
            )}
            
            {lastCapturedImage && (
              <ImageDisplay
                base64Image={lastCapturedImage.base64Data}
                title={`Captured Image (Index: ${lastCapturedImage.savedAtIndex})`}
                placeholder="No captured image"
              />
            )}
          </View>
        )}

        {/* Image Management */}
        <View style={styles.managementSection}>
          <Text style={styles.sectionTitle}>Image Management</Text>
          <View style={styles.buttonGrid}>
            <Button
              title="Get NFIQ Score"
              onPress={handleGetNfiqScore}
              disabled={!isConnected}
              variant="secondary"
              style={styles.gridButton}
            />
            <Button
              title="Get WSQ Image"
              onPress={handleGetWSQImage}
              disabled={!isConnected}
              variant="secondary"
              style={styles.gridButton}
            />
            <Button
              title="Check Duplication"
              onPress={handleCheckDuplication}
              disabled={!isConnected}
              variant="secondary"
              style={styles.gridButton}
            />
            <Button
              title="Clear Images"
              onPress={handleClearImages}
              disabled={!isConnected}
              variant="danger"
              style={styles.gridButton}
            />
          </View>
        </View>

        {/* Instructions */}
        <View style={styles.instructionsSection}>
          <Text style={styles.sectionTitle}>Instructions</Text>
          <Text style={styles.instructionText}>
            1. Set the desired save index (0-9) for captured images{'\n'}
            2. Choose capture type and follow device prompts{'\n'}
            3. View live preview during capture{'\n'}
            4. Use management tools to analyze saved images{'\n'}
            5. Clear images when storage slots are full
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    padding: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  inputSection: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  inputLabel: {
    flex: 1,
    fontSize: 14,
    color: '#333',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    padding: 8,
    width: 60,
    textAlign: 'center',
    fontSize: 16,
  },
  captureSection: {
    marginBottom: 16,
  },
  buttonGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  gridButton: {
    width: '48%',
    marginBottom: 8,
  },
  cancelButton: {
    marginTop: 8,
  },
  imageSection: {
    marginBottom: 16,
  },
  managementSection: {
    marginBottom: 16,
  },
  instructionsSection: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 32,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  instructionText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
});

export default FingerprintScreen;