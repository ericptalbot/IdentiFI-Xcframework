/**
 * Settings Screen
 * 
 * Screen for device settings and configuration
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Alert,
  TextInput,
  Switch,
} from 'react-native';
import { useIdentiFI } from '../hooks/useIdentiFI';
import Button from '../components/common/Button';
import StatusCard from '../components/common/StatusCard';

const SettingsScreen: React.FC = () => {
  const {
    deviceState,
    isConnected,
    setLEDBrightness,
    getLEDBrightness,
    setMinimumNFIQScore,
    setFpPowerOn,
    setFpPowerOff,
    getFpPowerStatus,
    refreshSettings,
  } = useIdentiFI();

  const [ledBrightness, setLedBrightnessInput] = useState('50');
  const [nfiqScore, setNfiqScoreInput] = useState('3');
  const [fpPowerEnabled, setFpPowerEnabled] = useState(false);

  const handleSetLEDBrightness = async () => {
    const brightness = parseInt(ledBrightness, 10);
    if (isNaN(brightness) || brightness < 0 || brightness > 100) {
      Alert.alert('Invalid Brightness', 'Please enter a value between 0 and 100');
      return;
    }

    try {
      await setLEDBrightness(brightness);
      Alert.alert('Success', `LED brightness set to ${brightness}%`);
    } catch (error) {
      Alert.alert(
        'Settings Error',
        error instanceof Error ? error.message : 'Failed to set LED brightness',
        [{ text: 'OK' }]
      );
    }
  };

  const handleGetLEDBrightness = async () => {
    try {
      await getLEDBrightness();
    } catch (error) {
      Alert.alert(
        'Settings Error',
        error instanceof Error ? error.message : 'Failed to get LED brightness',
        [{ text: 'OK' }]
      );
    }
  };

  const handleSetNFIQScore = async () => {
    const score = parseInt(nfiqScore, 10);
    if (isNaN(score) || score < 1 || score > 5) {
      Alert.alert('Invalid NFIQ Score', 'Please enter a value between 1 and 5');
      return;
    }

    try {
      await setMinimumNFIQScore(score);
      Alert.alert('Success', `Minimum NFIQ score set to ${score}`);
    } catch (error) {
      Alert.alert(
        'Settings Error',
        error instanceof Error ? error.message : 'Failed to set NFIQ score',
        [{ text: 'OK' }]
      );
    }
  };

  const handleFingerprintPowerToggle = async (enabled: boolean) => {
    try {
      setFpPowerEnabled(enabled);
      if (enabled) {
        await setFpPowerOn();
        Alert.alert('Success', 'Fingerprint sensor powered on');
      } else {
        await setFpPowerOff();
        Alert.alert('Success', 'Fingerprint sensor powered off');
      }
    } catch (error) {
      // Revert switch state on error
      setFpPowerEnabled(!enabled);
      Alert.alert(
        'Power Error',
        error instanceof Error ? error.message : 'Failed to change power state',
        [{ text: 'OK' }]
      );
    }
  };

  const handleCheckFpPowerStatus = async () => {
    try {
      await getFpPowerStatus();
    } catch (error) {
      Alert.alert(
        'Status Error',
        error instanceof Error ? error.message : 'Failed to get power status',
        [{ text: 'OK' }]
      );
    }
  };

  const handleRefreshSettings = async () => {
    try {
      await refreshSettings();
    } catch (error) {
      Alert.alert(
        'Refresh Error',
        error instanceof Error ? error.message : 'Failed to refresh settings',
        [{ text: 'OK' }]
      );
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.headerTitle}>Device Settings</Text>
        <Text style={styles.headerSubtitle}>
          Configure your IdentiFI device settings
        </Text>

        {!isConnected && (
          <StatusCard
            title="Connection Required"
            status="Please connect to device to access settings"
            statusType="warning"
          />
        )}

        {/* LED Brightness Settings */}
        <View style={styles.settingSection}>
          <Text style={styles.sectionTitle}>LED Brightness</Text>
          <View style={styles.settingCard}>
            <Text style={styles.settingDescription}>
              Adjust the brightness of device LEDs (0-100%)
            </Text>
            <View style={styles.inputRow}>
              <Text style={styles.inputLabel}>Brightness:</Text>
              <TextInput
                style={styles.textInput}
                value={ledBrightness}
                onChangeText={setLedBrightnessInput}
                keyboardType="numeric"
                maxLength={3}
                placeholder="0-100"
              />
              <Text style={styles.inputUnit}>%</Text>
            </View>
            <View style={styles.buttonRow}>
              <Button
                title="Set Brightness"
                onPress={handleSetLEDBrightness}
                disabled={!isConnected}
                style={styles.settingButton}
              />
              <Button
                title="Get Current"
                onPress={handleGetLEDBrightness}
                disabled={!isConnected}
                variant="secondary"
                style={styles.settingButton}
              />
            </View>
            {deviceState.settings.ledBrightness !== undefined && (
              <Text style={styles.currentValue}>
                Current: {deviceState.settings.ledBrightness}%
              </Text>
            )}
          </View>
        </View>

        {/* NFIQ Score Settings */}
        <View style={styles.settingSection}>
          <Text style={styles.sectionTitle}>Minimum NFIQ Score</Text>
          <View style={styles.settingCard}>
            <Text style={styles.settingDescription}>
              Set minimum quality score for fingerprint acceptance (1-5, where 1 is highest quality)
            </Text>
            <View style={styles.inputRow}>
              <Text style={styles.inputLabel}>Min Score:</Text>
              <TextInput
                style={styles.textInput}
                value={nfiqScore}
                onChangeText={setNfiqScoreInput}
                keyboardType="numeric"
                maxLength={1}
                placeholder="1-5"
              />
            </View>
            <Button
              title="Set NFIQ Score"
              onPress={handleSetNFIQScore}
              disabled={!isConnected}
              style={styles.fullWidthButton}
            />
            {deviceState.settings.minimumNFIQScore !== undefined && (
              <Text style={styles.currentValue}>
                Current: {deviceState.settings.minimumNFIQScore}
              </Text>
            )}
          </View>
        </View>

        {/* Power Management */}
        <View style={styles.settingSection}>
          <Text style={styles.sectionTitle}>Power Management</Text>
          <View style={styles.settingCard}>
            <View style={styles.switchRow}>
              <Text style={styles.switchLabel}>Fingerprint Sensor Power</Text>
              <Switch
                value={fpPowerEnabled}
                onValueChange={handleFingerprintPowerToggle}
                disabled={!isConnected}
                trackColor={{ false: '#ccc', true: '#007AFF' }}
                thumbColor={fpPowerEnabled ? '#fff' : '#f4f3f4'}
              />
            </View>
            <Text style={styles.settingDescription}>
              Toggle fingerprint sensor power to conserve battery
            </Text>
            <Button
              title="Check Power Status"
              onPress={handleCheckFpPowerStatus}
              disabled={!isConnected}
              variant="secondary"
              style={styles.fullWidthButton}
            />
            {deviceState.powerStatus.fingerprintSensorPowered !== undefined && (
              <Text style={styles.currentValue}>
                Status: {deviceState.powerStatus.fingerprintSensorPowered ? 'ON' : 'OFF'}
              </Text>
            )}
          </View>
        </View>

        {/* Settings Actions */}
        <View style={styles.actionsSection}>
          <Text style={styles.sectionTitle}>Actions</Text>
          <Button
            title="Refresh All Settings"
            onPress={handleRefreshSettings}
            disabled={!isConnected}
            variant="secondary"
            size="large"
            style={styles.actionButton}
          />
        </View>

        {/* Settings Information */}
        <View style={styles.infoSection}>
          <Text style={styles.sectionTitle}>Settings Information</Text>
          <Text style={styles.infoText}>
            <Text style={styles.boldText}>LED Brightness:</Text> Controls the intensity of all device LEDs including power, fingerprint, communication, and iris LEDs.{'\n\n'}
            
            <Text style={styles.boldText}>NFIQ Score:</Text> National Institute of Standards and Technology (NIST) Fingerprint Image Quality score. Lower numbers indicate higher quality (1=excellent, 5=poor).{'\n\n'}
            
            <Text style={styles.boldText}>Power Management:</Text> Individual sensors can be powered on/off to extend battery life when not in use.
          </Text>
        </View>

        {/* Troubleshooting */}
        <View style={styles.troubleshootingSection}>
          <Text style={styles.sectionTitle}>Troubleshooting</Text>
          <Text style={styles.troubleshootingText}>
            • If settings don't apply, ensure device connection is stable{'\n'}
            • LED brightness changes may take a few seconds to take effect{'\n'}
            • Power settings are reset when device is restarted{'\n'}
            • Some settings require specific firmware versions
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    padding: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  settingSection: {
    marginBottom: 20,
  },
  settingCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  settingDescription: {
    fontSize: 14,
    color: '#666',
    marginBottom: 12,
    lineHeight: 20,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  inputLabel: {
    flex: 1,
    fontSize: 14,
    color: '#333',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    padding: 8,
    width: 80,
    textAlign: 'center',
    fontSize: 16,
    marginRight: 8,
  },
  inputUnit: {
    fontSize: 14,
    color: '#666',
    width: 20,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  settingButton: {
    width: '48%',
  },
  fullWidthButton: {
    marginBottom: 8,
  },
  currentValue: {
    fontSize: 12,
    color: '#007AFF',
    fontWeight: '500',
    textAlign: 'center',
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  switchLabel: {
    fontSize: 16,
    color: '#333',
    flex: 1,
  },
  actionsSection: {
    marginBottom: 20,
  },
  actionButton: {
    marginVertical: 4,
  },
  infoSection: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  infoText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  boldText: {
    fontWeight: '600',
    color: '#333',
  },
  troubleshootingSection: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 32,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  troubleshootingText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
});

export default SettingsScreen;