/**
 * Device Info Screen
 * 
 * Screen displaying detailed device information and diagnostics
 */

import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  RefreshControl,
  Alert,
} from 'react-native';
import { useIdentiFI } from '../hooks/useIdentiFI';
import Button from '../components/common/Button';
import StatusCard from '../components/common/StatusCard';

const DeviceInfoScreen: React.FC = () => {
  const {
    deviceState,
    isConnected,
    refreshDeviceInfo,
    refreshPowerStatus,
  } = useIdentiFI();

  const [refreshing, setRefreshing] = useState(false);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);

  // Auto-refresh when connected
  useEffect(() => {
    if (isConnected) {
      handleRefresh();
    }
  }, [isConnected]);

  const handleRefresh = async () => {
    if (!isConnected) {
      Alert.alert('Not Connected', 'Please connect to device first');
      return;
    }

    setRefreshing(true);
    try {
      await Promise.all([
        refreshDeviceInfo(),
        refreshPowerStatus(),
      ]);
      setLastRefresh(new Date());
    } catch (error) {
      Alert.alert(
        'Refresh Error',
        error instanceof Error ? error.message : 'Failed to refresh device info',
        [{ text: 'OK' }]
      );
    } finally {
      setRefreshing(false);
    }
  };

  const getBatteryStatusType = (): 'success' | 'warning' | 'error' | 'info' => {
    const battery = deviceState.deviceInfo.batteryPercentage;
    if (battery === undefined) return 'info';
    if (battery > 50) return 'success';
    if (battery > 20) return 'warning';
    return 'error';
  };

  const formatLastRefresh = (): string => {
    if (!lastRefresh) return 'Never';
    return lastRefresh.toLocaleTimeString();
  };

  const getConnectionUptime = (): string => {
    // This would need to be tracked in the hook in a real implementation
    return 'Not available';
  };

  return (
    <ScrollView
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
      }
    >
      <View style={styles.content}>
        <Text style={styles.headerTitle}>Device Information</Text>
        <Text style={styles.headerSubtitle}>
          Detailed information about your IdentiFI device
        </Text>

        {!isConnected && (
          <StatusCard
            title="Device Status"
            status="Not Connected"
            statusType="error"
            subtitle="Connect to device to view information"
          />
        )}

        {/* Connection Information */}
        {isConnected && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Connection Status</Text>
            <StatusCard
              title="Device Connection"
              status="Connected"
              statusType="success"
              subtitle={`Last refresh: ${formatLastRefresh()}`}
            />
            <StatusCard
              title="Connection Uptime"
              status={getConnectionUptime()}
              statusType="info"
            />
          </View>
        )}

        {/* Device Hardware Information */}
        {isConnected && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Hardware Information</Text>
            
            {deviceState.deviceInfo.modelNumber && (
              <StatusCard
                title="Model Number"
                status={deviceState.deviceInfo.modelNumber}
                statusType="info"
              />
            )}
            
            {deviceState.deviceInfo.serialNumber && (
              <StatusCard
                title="Serial Number"
                status={deviceState.deviceInfo.serialNumber}
                statusType="info"
              />
            )}
            
            {deviceState.deviceInfo.description && (
              <StatusCard
                title="Device Description"
                status={deviceState.deviceInfo.description}
                statusType="info"
              />
            )}
          </View>
        )}

        {/* Software Information */}
        {isConnected && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Software Information</Text>
            
            {deviceState.deviceInfo.firmwareVersion && (
              <StatusCard
                title="Firmware Version"
                status={deviceState.deviceInfo.firmwareVersion}
                statusType="info"
              />
            )}
            
            {deviceState.deviceInfo.libraryVersion && (
              <StatusCard
                title="SDK Library Version"
                status={deviceState.deviceInfo.libraryVersion}
                statusType="info"
              />
            )}
          </View>
        )}

        {/* Power and Battery Information */}
        {isConnected && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Power Status</Text>
            
            {deviceState.deviceInfo.batteryPercentage !== undefined && (
              <StatusCard
                title="Battery Level"
                status={`${deviceState.deviceInfo.batteryPercentage}%`}
                statusType={getBatteryStatusType()}
                subtitle={
                  deviceState.deviceInfo.batteryPercentage < 20
                    ? 'Low battery - consider charging'
                    : undefined
                }
              />
            )}
            
            <StatusCard
              title="Fingerprint Sensor"
              status={deviceState.powerStatus.fingerprintSensorPowered ? 'Powered On' : 'Powered Off'}
              statusType={deviceState.powerStatus.fingerprintSensorPowered ? 'success' : 'warning'}
            />
            
            <StatusCard
              title="Iris Sensor"
              status={deviceState.powerStatus.irisSensorPowered ? 'Powered On' : 'Powered Off'}
              statusType={deviceState.powerStatus.irisSensorPowered ? 'success' : 'warning'}
            />
            
            {deviceState.powerStatus.powerOffModeSeconds !== undefined && (
              <StatusCard
                title="Auto Power Off"
                status={`${deviceState.powerStatus.powerOffModeSeconds} seconds`}
                statusType="info"
              />
            )}
          </View>
        )}

        {/* Current Settings */}
        {isConnected && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Current Settings</Text>
            
            {deviceState.settings.ledBrightness !== undefined && (
              <StatusCard
                title="LED Brightness"
                status={`${deviceState.settings.ledBrightness}%`}
                statusType="info"
              />
            )}
            
            {deviceState.settings.minimumNFIQScore !== undefined && (
              <StatusCard
                title="Minimum NFIQ Score"
                status={`${deviceState.settings.minimumNFIQScore}`}
                statusType="info"
                subtitle="Lower values require higher quality fingerprints"
              />
            )}
          </View>
        )}

        {/* Device Capabilities */}
        {isConnected && deviceState.deviceInfo.modelNumber && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Device Capabilities</Text>
            
            <StatusCard
              title="Fingerprint Capture"
              status="Supported"
              statusType="success"
              subtitle="1, 2, 4 finger flat and rolled captures"
            />
            
            <StatusCard
              title="Iris Capture"
              status={
                deviceState.deviceInfo.modelNumber.includes('-45I') || 
                deviceState.deviceInfo.modelNumber.includes('-50I')
                  ? 'Supported'
                  : 'Not Supported'
              }
              statusType={
                deviceState.deviceInfo.modelNumber.includes('-45I') || 
                deviceState.deviceInfo.modelNumber.includes('-50I')
                  ? 'success'
                  : 'warning'
              }
              subtitle="Dual iris capture with quality scoring"
            />
            
            <StatusCard
              title="WSQ Compression"
              status="Supported"
              statusType="success"
              subtitle="FBI-compliant image compression"
            />
            
            <StatusCard
              title="NFIQ Quality Scoring"
              status="Supported"
              statusType="success"
              subtitle="NIST Fingerprint Image Quality assessment"
            />
          </View>
        )}

        {/* Refresh Controls */}
        {isConnected && (
          <View style={styles.actionsSection}>
            <Text style={styles.sectionTitle}>Actions</Text>
            <Button
              title="Refresh Device Info"
              onPress={handleRefresh}
              loading={refreshing}
              disabled={refreshing}
              size="large"
              style={styles.refreshButton}
            />
          </View>
        )}

        {/* Diagnostic Information */}
        <View style={styles.diagnosticSection}>
          <Text style={styles.sectionTitle}>Diagnostic Information</Text>
          <View style={styles.diagnosticCard}>
            <Text style={styles.diagnosticText}>
              <Text style={styles.boldText}>React Native Version:</Text> 0.80.2{'\n'}
              <Text style={styles.boldText}>IdentiFI SDK Version:</Text> 1.6.0.0{'\n'}
              <Text style={styles.boldText}>Platform:</Text> iOS{'\n'}
              <Text style={styles.boldText}>Architecture:</Text> arm64{'\n'}
              <Text style={styles.boldText}>Last Refresh:</Text> {formatLastRefresh()}
            </Text>
          </View>
        </View>

        {/* Support Information */}
        <View style={styles.supportSection}>
          <Text style={styles.sectionTitle}>Support</Text>
          <Text style={styles.supportText}>
            For technical support or questions about your IdentiFI device:
            {'\n\n'}
            • Visit the official documentation{'\n'}
            • Contact S.I.C. Biometrics support{'\n'}
            • Check firmware update availability{'\n'}
            • Review device compatibility requirements
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    padding: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 24,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  actionsSection: {
    marginBottom: 20,
  },
  refreshButton: {
    marginVertical: 4,
  },
  diagnosticSection: {
    marginBottom: 20,
  },
  diagnosticCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  diagnosticText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  boldText: {
    fontWeight: '600',
    color: '#333',
  },
  supportSection: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 32,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  supportText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
});

export default DeviceInfoScreen;