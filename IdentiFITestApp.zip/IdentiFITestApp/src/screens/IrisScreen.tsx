/**
 * Iris Screen
 * 
 * Screen for iris capture operations
 */

import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Alert,
} from 'react-native';
import { useIdentiFI } from '../hooks/useIdentiFI';
import Button from '../components/common/Button';
import StatusCard from '../components/common/StatusCard';
import ImageDisplay from '../components/common/ImageDisplay';

const IrisScreen: React.FC = () => {
  const {
    isConnected,
    isCapturing,
    lastIrisImage,
    startCaptureIris,
    cancelIrisCapture,
    setIrisPowerOn,
    setIrisPowerOff,
    getIrisPowerStatus,
  } = useIdentiFI();

  const handleStartCapture = async () => {
    if (!isConnected) {
      Alert.alert('Not Connected', 'Please connect to the device first');
      return;
    }

    try {
      await startCaptureIris();
    } catch (error) {
      Alert.alert(
        'Capture Error',
        error instanceof Error ? error.message : 'Failed to start iris capture',
        [{ text: 'OK' }]
      );
    }
  };

  const handleCancelCapture = async () => {
    try {
      await cancelIrisCapture();
    } catch (error) {
      Alert.alert(
        'Cancel Error',
        error instanceof Error ? error.message : 'Failed to cancel iris capture',
        [{ text: 'OK' }]
      );
    }
  };

  const handlePowerOn = async () => {
    try {
      await setIrisPowerOn();
      Alert.alert('Success', 'Iris sensor powered on');
    } catch (error) {
      Alert.alert(
        'Power Error',
        error instanceof Error ? error.message : 'Failed to power on iris sensor',
        [{ text: 'OK' }]
      );
    }
  };

  const handlePowerOff = async () => {
    try {
      await setIrisPowerOff();
      Alert.alert('Success', 'Iris sensor powered off');
    } catch (error) {
      Alert.alert(
        'Power Error',
        error instanceof Error ? error.message : 'Failed to power off iris sensor',
        [{ text: 'OK' }]
      );
    }
  };

  const handleCheckPowerStatus = async () => {
    try {
      await getIrisPowerStatus();
    } catch (error) {
      Alert.alert(
        'Status Error',
        error instanceof Error ? error.message : 'Failed to get iris power status',
        [{ text: 'OK' }]
      );
    }
  };

  const getCaptureStatusText = (): string => {
    if (!isConnected) return 'Device not connected';
    if (isCapturing) return 'Capturing iris images...';
    return 'Ready for iris capture';
  };

  const getCaptureStatusType = (): 'success' | 'warning' | 'error' | 'info' => {
    if (!isConnected) return 'error';
    if (isCapturing) return 'info';
    return 'success';
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.headerTitle}>Iris Capture</Text>
        <Text style={styles.headerSubtitle}>
          Capture and manage iris images
        </Text>

        {/* Capture Status */}
        <StatusCard
          title="Capture Status"
          status={getCaptureStatusText()}
          statusType={getCaptureStatusType()}
        />

        {/* Power Management */}
        <View style={styles.powerSection}>
          <Text style={styles.sectionTitle}>Iris Sensor Power</Text>
          <View style={styles.buttonRow}>
            <Button
              title="Power On"
              onPress={handlePowerOn}
              disabled={!isConnected}
              style={styles.powerButton}
            />
            <Button
              title="Power Off"
              onPress={handlePowerOff}
              disabled={!isConnected}
              variant="danger"
              style={styles.powerButton}
            />
          </View>
          <Button
            title="Check Status"
            onPress={handleCheckPowerStatus}
            disabled={!isConnected}
            variant="secondary"
            style={styles.statusButton}
          />
        </View>

        {/* Capture Controls */}
        <View style={styles.captureSection}>
          <Text style={styles.sectionTitle}>Capture Controls</Text>
          
          {!isCapturing ? (
            <Button
              title="Start Iris Capture"
              onPress={handleStartCapture}
              disabled={!isConnected}
              size="large"
              style={styles.captureButton}
            />
          ) : (
            <Button
              title="Cancel Capture"
              onPress={handleCancelCapture}
              variant="danger"
              size="large"
              style={styles.captureButton}
            />
          )}
        </View>

        {/* Image Display */}
        {lastIrisImage && (
          <View style={styles.imageSection}>
            <Text style={styles.sectionTitle}>Captured Iris Images</Text>
            
            <View style={styles.irisContainer}>
              <ImageDisplay
                base64Image={lastIrisImage.leftIrisBase64}
                title="Left Iris"
                placeholder="No left iris image"
                style={styles.irisImage}
              />
              
              <ImageDisplay
                base64Image={lastIrisImage.rightIrisBase64}
                title="Right Iris"
                placeholder="No right iris image"
                style={styles.irisImage}
              />
            </View>

            {/* Iris Quality Scores */}
            <View style={styles.scoresSection}>
              <Text style={styles.sectionTitle}>Quality Scores</Text>
              <StatusCard
                title="Left Iris"
                status={`Total Score: ${lastIrisImage.leftTotalScore}, Usable Area: ${lastIrisImage.leftUsableArea}`}
                statusType="info"
              />
              <StatusCard
                title="Right Iris"
                status={`Total Score: ${lastIrisImage.rightTotalScore}, Usable Area: ${lastIrisImage.rightUsableArea}`}
                statusType="info"
              />
            </View>
          </View>
        )}

        {/* Instructions */}
        <View style={styles.instructionsSection}>
          <Text style={styles.sectionTitle}>Instructions</Text>
          <Text style={styles.instructionText}>
            1. Power on the iris sensor before capture{'\n'}
            2. Position eyes approximately 6-8 inches from the device{'\n'}
            3. Look directly at the iris sensor{'\n'}
            4. Keep eyes open and steady during capture{'\n'}
            5. Follow device prompts for optimal positioning{'\n'}
            6. Power off sensor when finished to conserve battery
          </Text>
        </View>

        {/* Device Compatibility */}
        <View style={styles.compatibilitySection}>
          <Text style={styles.sectionTitle}>Device Compatibility</Text>
          <Text style={styles.compatibilityText}>
            Iris capture is supported on IdentiFI-45I and IdentiFI-50I models.
            Make sure your device firmware is version 2.3.0 or higher for optimal performance.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    padding: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  powerSection: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  powerButton: {
    width: '48%',
  },
  statusButton: {
    marginTop: 4,
  },
  captureSection: {
    marginBottom: 16,
  },
  captureButton: {
    marginVertical: 8,
  },
  imageSection: {
    marginBottom: 16,
  },
  irisContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  irisImage: {
    width: '48%',
  },
  scoresSection: {
    marginTop: 16,
  },
  instructionsSection: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  instructionText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  compatibilitySection: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 32,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  compatibilityText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
    fontStyle: 'italic',
  },
});

export default IrisScreen;