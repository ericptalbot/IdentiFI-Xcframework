/**
 * Connection Screen
 * 
 * Main screen for managing IdentiFI device connection
 */

import React, { useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Alert,
  RefreshControl,
} from 'react-native';
import { useIdentiFI } from '../hooks/useIdentiFI';
import { ConnectionStatus } from '../types/IdentiFI';
import Button from '../components/common/Button';
import StatusCard from '../components/common/StatusCard';

const ConnectionScreen: React.FC = () => {
  const {
    deviceState,
    isConnected,
    isConnecting,
    connect,
    disconnect,
    refreshDeviceInfo,
  } = useIdentiFI();

  const [refreshing, setRefreshing] = React.useState(false);

  // Auto-refresh device info when connected
  useEffect(() => {
    if (isConnected) {
      refreshDeviceInfo().catch(console.error);
    }
  }, [isConnected, refreshDeviceInfo]);

  const handleConnect = async () => {
    try {
      await connect();
    } catch (error) {
      Alert.alert(
        'Connection Error',
        error instanceof Error ? error.message : 'Failed to connect to device',
        [{ text: 'OK' }]
      );
    }
  };

  const handleDisconnect = async () => {
    try {
      await disconnect();
    } catch (error) {
      Alert.alert(
        'Disconnection Error',
        error instanceof Error ? error.message : 'Failed to disconnect from device',
        [{ text: 'OK' }]
      );
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      if (isConnected) {
        await refreshDeviceInfo();
      }
    } catch (error) {
      console.error('Refresh error:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const getConnectionStatusType = (): 'success' | 'warning' | 'error' | 'info' => {
    switch (deviceState.connectionStatus) {
      case ConnectionStatus.CONNECTED:
        return 'success';
      case ConnectionStatus.CONNECTING:
        return 'info';
      case ConnectionStatus.CONNECTION_ERROR:
      case ConnectionStatus.CONNECTION_TIMEOUT:
        return 'error';
      case ConnectionStatus.DISCONNECTED:
      default:
        return 'warning';
    }
  };

  const getConnectionStatusText = (): string => {
    switch (deviceState.connectionStatus) {
      case ConnectionStatus.CONNECTED:
        return 'Connected';
      case ConnectionStatus.CONNECTING:
        return 'Connecting...';
      case ConnectionStatus.CONNECTION_ERROR:
        return 'Connection Error';
      case ConnectionStatus.CONNECTION_TIMEOUT:
        return 'Connection Timeout';
      case ConnectionStatus.DISCONNECTED:
      default:
        return 'Disconnected';
    }
  };

  return (
    <ScrollView
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      <View style={styles.content}>
        <Text style={styles.headerTitle}>IdentiFI Device Connection</Text>
        <Text style={styles.headerSubtitle}>
          Manage connection to your IdentiFI biometric device
        </Text>

        {/* Connection Status */}
        <StatusCard
          title="Connection Status"
          status={getConnectionStatusText()}
          statusType={getConnectionStatusType()}
          subtitle={deviceState.lastError || undefined}
        />

        {/* Connection Controls */}
        <View style={styles.buttonContainer}>
          {!isConnected ? (
            <Button
              title="Connect to Device"
              onPress={handleConnect}
              loading={isConnecting}
              disabled={isConnecting}
              size="large"
              style={styles.button}
            />
          ) : (
            <Button
              title="Disconnect"
              onPress={handleDisconnect}
              variant="danger"
              size="large"
              style={styles.button}
            />
          )}
        </View>

        {/* Device Information */}
        {isConnected && (
          <View style={styles.deviceInfoSection}>
            <Text style={styles.sectionTitle}>Device Information</Text>
            
            {deviceState.deviceInfo.serialNumber && (
              <StatusCard
                title="Serial Number"
                status={deviceState.deviceInfo.serialNumber}
                statusType="info"
              />
            )}
            
            {deviceState.deviceInfo.modelNumber && (
              <StatusCard
                title="Model"
                status={deviceState.deviceInfo.modelNumber}
                statusType="info"
              />
            )}
            
            {deviceState.deviceInfo.firmwareVersion && (
              <StatusCard
                title="Firmware Version"
                status={deviceState.deviceInfo.firmwareVersion}
                statusType="info"
              />
            )}
            
            {deviceState.deviceInfo.libraryVersion && (
              <StatusCard
                title="Library Version"
                status={deviceState.deviceInfo.libraryVersion}
                statusType="info"
              />
            )}
            
            {deviceState.deviceInfo.batteryPercentage !== undefined && (
              <StatusCard
                title="Battery Level"
                status={`${deviceState.deviceInfo.batteryPercentage}%`}
                statusType={
                  deviceState.deviceInfo.batteryPercentage > 50
                    ? 'success'
                    : deviceState.deviceInfo.batteryPercentage > 20
                    ? 'warning'
                    : 'error'
                }
              />
            )}
          </View>
        )}

        {/* Instructions */}
        <View style={styles.instructionsSection}>
          <Text style={styles.sectionTitle}>Instructions</Text>
          <Text style={styles.instructionText}>
            1. Make sure your IdentiFI device is powered on and in pairing mode
            {'\n'}
            2. Tap "Connect to Device" to establish connection
            {'\n'}
            3. Once connected, device information will be displayed
            {'\n'}
            4. Use other tabs to access fingerprint and iris capture features
          </Text>
        </View>

        {/* Connection Help */}
        <View style={styles.helpSection}>
          <Text style={styles.sectionTitle}>Troubleshooting</Text>
          <Text style={styles.helpText}>
            • Ensure Bluetooth is enabled on your device{'\n'}
            • Check that the IdentiFI device is within range{'\n'}
            • Try restarting the IdentiFI device if connection fails{'\n'}
            • Contact support if problems persist
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    padding: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 24,
  },
  buttonContainer: {
    marginVertical: 16,
  },
  button: {
    marginVertical: 4,
  },
  deviceInfoSection: {
    marginTop: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  instructionsSection: {
    marginTop: 24,
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  instructionText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  helpSection: {
    marginTop: 16,
    marginBottom: 32,
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  helpText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
});

export default ConnectionScreen;