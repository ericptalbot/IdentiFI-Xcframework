# IdentiFI Test App - Build and Test Guide

## Prerequisites

Before building the app, ensure you have:
- Xcode 14+ installed
- iOS Simulator or physical iOS device (iOS 13.0+)
- IdentiFI hardware device for testing
- React Native development environment set up

## Step 1: Complete Xcode Integration

### 1.1 Copy the xcframework

First, manually copy the IdentiFI xcframework to the iOS project:

```bash
cd /Users/jean-baptistekerbrat/Documents/projects/IdentiFI/IdentiFITestApp
mkdir -p ios/Frameworks
cp -R ../IdentiFI-v1600.xcframework ios/Frameworks/
```

### 1.2 Open Xcode Workspace

```bash
open ios/IdentiFITestApp.xcworkspace
```

### 1.3 Add Framework to Project

1. In Xcode, select the `IdentiFITestApp` project in the navigator
2. Select the `IdentiFITestApp` target
3. Go to "General" tab
4. In "Frameworks, Libraries, and Embedded Content" section:
   - Click the "+" button
   - Click "Add Other..." → "Add Files..."
   - Navigate to `ios/Frameworks/IdentiFI-v1600.xcframework`
   - Select it and click "Open"
   - Make sure "Embed & Sign" is selected

### 1.4 Configure Build Settings

1. Go to "Build Settings" tab
2. Search for "Header Search Paths"
3. Add: `$(SRCROOT)/IdentiFITestApp` (recursive)
4. Search for "Framework Search Paths"
5. Add: `$(SRCROOT)/Frameworks` (recursive)

### 1.5 Configure Bridging Header

1. In Build Settings, search for "Objective-C Bridging Header"
2. Set to: `IdentiFITestApp/IdentiFITestApp-Bridging-Header.h`

### 1.6 Enable IdentiFI Import

Edit `ios/IdentiFITestApp/IdentiFITestApp-Bridging-Header.h`:

```objc
//
//  IdentiFITestApp-Bridging-Header.h
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "IdentiFI.h"
```

### 1.7 Activate IdentiFI Code in Bridge Module

Edit `ios/IdentiFITestApp/RNIdentiFIModule.m` and uncomment the IdentiFI code:

```objc
// In the init method, uncomment:
self.identiFIDevice = [[IdentiFI alloc] init];
[self.identiFIDevice setDelegate:self];

// In all RCT_EXPORT_METHOD implementations, uncomment the actual SDK calls
// For example, in connect method:
[self.identiFIDevice connect];

// At the end of the file, uncomment the entire delegate section
```

## Step 2: Install Dependencies

```bash
# Install npm dependencies
npm install

# Install iOS pods
cd ios
pod install
cd ..
```

## Step 3: Configure iOS Permissions

Add Bluetooth permissions to `ios/IdentiFITestApp/Info.plist`:

```xml
<key>NSBluetoothAlwaysUsageDescription</key>
<string>This app uses Bluetooth to connect to the IdentiFI biometric sensor</string>
<key>NSBluetoothPeripheralUsageDescription</key>
<string>This app uses Bluetooth to connect to the IdentiFI biometric sensor</string>
```

## Step 4: Build the App

### Option A: Build from Command Line

```bash
# Clean build (if needed)
npx react-native clean

# Start Metro bundler
npx react-native start

# In another terminal, build and run on iOS simulator
npx react-native run-ios

# Or run on specific simulator
npx react-native run-ios --simulator="iPhone 15"

# Or run on connected device
npx react-native run-ios --device
```

### Option B: Build from Xcode

1. Open `ios/IdentiFITestApp.xcworkspace` in Xcode
2. Select your target device/simulator
3. Press Cmd+R to build and run

## Step 5: Testing the App

### 5.1 Without Hardware (UI Testing)

You can test the UI and navigation without a physical IdentiFI device:

1. Launch the app
2. Navigate through tabs: Connection, Fingerprint, Iris, Settings, Device Info
3. Tap buttons to see log messages in Metro console
4. Check that all screens render correctly

### 5.2 With IdentiFI Hardware

For full testing with actual IdentiFI device:

1. **Power on your IdentiFI device**
2. **Enable Bluetooth** on your iOS device
3. **Launch the app**
4. **Go to Connection tab**
5. **Tap "Connect to Device"**
6. **Test fingerprint capture:**
   - Go to Fingerprint tab
   - Set save index (0-9)
   - Try different capture types
   - View captured images
7. **Test iris capture** (if supported):
   - Go to Iris tab
   - Power on iris sensor
   - Start capture
   - Position eyes correctly
8. **Test settings:**
   - Adjust LED brightness
   - Change NFIQ score
   - Manage power settings
9. **Check device info:**
   - View battery level
   - Check firmware version
   - See device capabilities

## Troubleshooting

### Build Errors

**Error: "RNIdentiFIModule not found"**
```bash
# Clean and rebuild
cd ios
rm -rf build
xcodebuild clean
cd ..
npx react-native clean
npm start -- --reset-cache
```

**Error: "IdentiFI.h file not found"**
- Verify the xcframework is properly added to Xcode project
- Check Header Search Paths in Build Settings
- Ensure bridging header path is correct

**Error: "Undefined symbols for IdentiFI"**
- Make sure xcframework is set to "Embed & Sign"
- Check Framework Search Paths
- Verify xcframework architecture matches your target

### Runtime Errors

**Error: "Module RNIdentiFIModule is not available"**
- Ensure native module is properly registered
- Check that bridging header includes IdentiFI.h
- Verify all IdentiFI code is uncommented

**Error: "Connection failed"**
- Check Bluetooth permissions in Info.plist
- Ensure IdentiFI device is powered on and in pairing mode
- Verify device compatibility

**Error: "Images not displaying"**
- Check base64 image format in callbacks
- Verify image data is properly received
- Check network/memory constraints

### Device-Specific Issues

**IdentiFI Device Not Found:**
1. Ensure device is powered on
2. Check Bluetooth is enabled
3. Try restarting the IdentiFI device
4. Check device compatibility with your model

**Poor Capture Quality:**
1. Clean the sensor surface
2. Ensure proper finger/eye positioning
3. Adjust LED brightness if needed
4. Check minimum NFIQ score settings

**Battery Issues:**
1. Charge the IdentiFI device
2. Monitor battery level in Device Info tab
3. Use power management features to conserve battery

## Performance Optimization

### For Development

```bash
# Use development mode for faster builds
npx react-native run-ios --mode Debug

# Enable fast refresh for quick UI changes
# This is enabled by default in Metro
```

### For Production Testing

```bash
# Build release version for performance testing
npx react-native run-ios --mode Release

# Or build archive in Xcode for distribution
```

## Debugging

### React Native Debugger

1. Install React Native Debugger
2. Enable debugging in app (Cmd+D in simulator)
3. Select "Debug JS Remotely"
4. Monitor network requests and state changes

### Xcode Console

1. Open Xcode console (Window → Devices and Simulators)
2. Select your device
3. View native logs and crash reports
4. Monitor IdentiFI SDK native method calls

### Metro Console

Monitor JavaScript logs in the Metro bundler terminal:
- Connection status changes
- Capture events
- Error messages
- Performance metrics

## Next Steps

Once the app is built and running:

1. **Test all core features** with your IdentiFI device
2. **Customize UI/UX** for your specific use case
3. **Add error handling** for your deployment scenario
4. **Implement data persistence** if needed
5. **Add analytics/logging** for production monitoring
6. **Create automated tests** for CI/CD pipeline

## Support

If you encounter issues:

1. Check the `API_DOCUMENTATION.md` for method details
2. Review `INTEGRATION_GUIDE.md` for setup steps
3. Consult IdentiFI SDK documentation
4. Contact S.I.C. Biometrics support for hardware issues

## Build Verification Checklist

- [ ] xcframework properly added to Xcode project
- [ ] Bridging header configured and includes IdentiFI.h
- [ ] All IdentiFI native code uncommented in bridge module
- [ ] Bluetooth permissions added to Info.plist
- [ ] App builds without errors
- [ ] All tabs navigate correctly
- [ ] Connection to IdentiFI device works
- [ ] Fingerprint capture functions
- [ ] Iris capture works (if supported device)
- [ ] Settings can be modified
- [ ] Device info displays correctly
- [ ] Images display properly
- [ ] Error handling works as expected

Your IdentiFI Test App is now ready for comprehensive testing!